/* =================================================
   chart.js — Chart rendering functions
   คลังอะไหล่เมาท์เทน | C-FACTORY WMS
   ================================================= */

        function renderDashboardChart(data) {
            try {
                const ctx = document.getElementById('catStockChart'); if(!ctx) return;
                const catMap = {};
                data.items.forEach(i => { let cat = getItemCategory(i); if(cat) catMap[cat] = (catMap[cat]||0) + 1; });
                data.tools.forEach(t => { let cat = getItemCategory(t); if(cat) catMap[cat] = (catMap[cat]||0) + 1; });
                const labels = Object.keys(catMap); const values = Object.values(catMap); 
                const dynamicColors = labels.map((_, i) => `hsl(${(i * 137.5) % 360}, 75%, 55%)`);
                if(charts.catStock) charts.catStock.destroy();
                charts.catStock = new Chart(ctx.getContext('2d'), { type: 'doughnut', data: { labels: labels.length > 0 ? labels : ['ไม่มีข้อมูล'], datasets: [{ data: values.length > 0 ? values : [1], backgroundColor: values.length > 0 ? dynamicColors : ['#f1f5f9'], borderWidth: 2, borderColor: '#ffffff' }] }, options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { position: 'right', labels: { boxWidth: 10, padding: 15, font: { family: 'Prompt', size: 12 }, usePointStyle: true } } } } });
            } catch(e) { console.error(e); }
        }
