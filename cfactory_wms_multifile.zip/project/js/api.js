/* =================================================
   api.js — Global state, GAS bridge, data layer
   คลังอะไหล่เมาท์เทน | C-FACTORY WMS
   ================================================= */

let allData = { items: [], tools: [], history: [], activeBorrows: [], pendingPOs: [], users: [], settings: {} };
        let charts = {};
        let adjustModal, addPOModal, editPOModal, txModal, addBorrowModal, damageModal, repairModal, newItemModal, editItemModal, qrActionModal, changePinModal;
        let sessionTimer;
        let currentUserProfile = { name: 'Web Admin', uid: null, role: 'admin' };
        let autoRefreshTimer = null;
        let isFetchingData = false;
        let html5QrCode = null;
        let scannedItemContext = null;
        let selectedQRCodes = new Set(); 

        window.onload = resetSessionTimer;
        document.onmousemove = resetSessionTimer;
        document.onkeypress = resetSessionTimer;

        /* ─── Component Loader ─────────────────────────────────────
   Load HTML components from separate files, then initialize
   ─────────────────────────────────────────────────────── */
async function loadComponent(containerId, filePath) {
    try {
        const res = await fetch(filePath);
        if (!res.ok) throw new Error(`Failed to load ${filePath}: ${res.status}`);
        const html = await res.text();
        const container = document.getElementById(containerId);
        if (container) container.innerHTML = html;
    } catch (e) {
        console.error('Component load error:', e);
    }
}

async function loadPageSection(sectionId, filePath) {
    try {
        const res = await fetch(filePath);
        if (!res.ok) throw new Error(`Failed to load ${filePath}: ${res.status}`);
        const html = await res.text();
        // Parse response, strip outer wrapper div, inject inner content
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const section = doc.body.firstElementChild;
        const container = document.getElementById(sectionId);
        if (container && section) {
            // Copy inner HTML (keep the container div in index.html as anchor)
            container.innerHTML = section.innerHTML;
            // Copy classes from page file if needed
            if (section.className) {
                section.className.split(' ').forEach(c => {
                    if (c && c !== 'section-view') container.classList.add(c);
                });
            }
        }
    } catch (e) {
        console.error('Page section load error:', sectionId, e);
    }
}

document.addEventListener('DOMContentLoaded', async function() {
    // 1. Load structural components
    await Promise.all([
        loadComponent('navbar-container',       './components/navbar.html'),
        loadComponent('modals-container',       './components/sidebar.html'),
        loadComponent('scanner-panel-container','./components/footer.html'),
    ]);

    // 2. Load page sections
    await Promise.all([
        loadPageSection('dashboard',         './pages/dashboard.html'),
        loadPageSection('transactionsInOut', './pages/transactionsInOut.html'),
        loadPageSection('borrowedItems',     './pages/borrowedItems.html'),
        loadPageSection('monthlyOrders',     './pages/monthlyOrders.html'),
        loadPageSection('items',             './pages/items.html'),
        loadPageSection('tools',             './pages/tools.html'),
        loadPageSection('qrManagement',      './pages/qrManagement.html'),
        loadPageSection('history',           './pages/history.html'),
        loadPageSection('settings',          './pages/settings.html'),
    ]);

    // 3. Initialize Bootstrap modals (now that DOM has all modals)
    // sidebar hidden in top-nav layout — skip toggle listener
    adjustModal = new bootstrap.Modal(document.getElementById('adjustStockModal'));
            addPOModal = new bootstrap.Modal(document.getElementById('addPOModal'));
            editPOModal = new bootstrap.Modal(document.getElementById('editPOModal'));
            txModal = new bootstrap.Modal(document.getElementById('txModal'));
            addBorrowModal = new bootstrap.Modal(document.getElementById('addBorrowModal'));
            damageModal = new bootstrap.Modal(document.getElementById('damageModal'));
            repairModal = new bootstrap.Modal(document.getElementById('repairModal'));
            newItemModal = new bootstrap.Modal(document.getElementById('newItemModal'));
            editItemModal = new bootstrap.Modal(document.getElementById('editItemModal'));
            qrActionModal = new bootstrap.Modal(document.getElementById('qrActionModal'));
            changePinModal = new bootstrap.Modal(document.getElementById('changePinModal'));
            
            // qrScannerModal replaced by scannerPanel - no modal listener needed

            checkLogin();
        });

        function resetSessionTimer() { 
            clearTimeout(sessionTimer); 
            let to = parseInt(allData.settings?.sessionTimeout) || 30; 
            let loginScreen = document.getElementById('loginScreen');
            if(loginScreen && window.getComputedStyle(loginScreen).display === 'none') { 
                sessionTimer = setTimeout(logoutAuto, to * 60000); 
            } 
        }
        
        function logoutAuto() { 
            Swal.fire({icon: 'warning', title: 'หมดเวลาเซสชัน', text: 'ไม่มีการใช้งานนานเกินกำหนด กรุณาเข้าสู่ระบบใหม่', confirmButtonText: 'ตกลง', confirmButtonColor: 'var(--primary-color)'}).then(() => forceLogoutToScreen()); 
        }
        

        function previewLogo(url) {
            const img = document.getElementById('logoPreviewImg');
            const icon = document.getElementById('logoPlaceholderIcon');
            if (!img) return;
            if (url && url.startsWith('http')) {
                img.src = url;
                img.style.display = 'block';
                if (icon) icon.style.display = 'none';
                img.onerror = function() {
                    img.style.display = 'none';
                    if (icon) icon.style.display = 'block';
                };
            } else {
                img.style.display = 'none';
                if (icon) icon.style.display = 'block';
            }
        }
        function logout() { 
            Swal.fire({
                title: 'ออกจากระบบ?',
                text: 'คุณต้องการออกจากระบบใช่หรือไม่?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'ออกจากระบบ',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if(result.isConfirmed) {
                    writeAudit('LOGOUT', `ออกจากระบบโดยผู้ใช้ — ${currentUserProfile.name}`);
                    forceLogoutToScreen();
                }
            });
        }
        
        function forceLogoutToScreen() {
            document.getElementById('loginScreen').style.display = 'flex';
            document.getElementById('loginPin').value = '';
            document.getElementById('loginUid').value = '';
            currentUserProfile = { name: 'Web Admin', uid: null, role: 'admin' };
            if (window.history && window.history.pushState) {
                var cleanUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
                window.history.pushState({path: cleanUrl}, '', cleanUrl);
            }
            if(autoRefreshTimer) { clearInterval(autoRefreshTimer); autoRefreshTimer = null; }
        }

        function toggleAutoRefresh(isChecked) { 
            const el = document.getElementById('autoRefreshOptions'); 
            if(el) el.style.display = isChecked ? 'block' : 'none'; 
        }

        function setupAutoRefresh(s) {
            if(autoRefreshTimer) { clearInterval(autoRefreshTimer); autoRefreshTimer = null; }
            if(s && s.autoRefresh) {
                let sec = parseInt(s.refreshInterval); if(isNaN(sec) || sec < 3) sec = 3;
                autoRefreshTimer = setInterval(() => { 
                    if(document.body.classList.contains('modal-open')) return;
                    if(isFetchingData) return;
                    loadData(true); 
                }, sec * 1000);
            }
        }

        function goTo(sectionId) {
            // Top-nav active state
            document.querySelectorAll('.topnav-menu a').forEach(function(el) {
                el.classList.remove('active');
                if(el.getAttribute('onclick') && el.getAttribute('onclick').indexOf("'" + sectionId + "'") !== -1) {
                    el.classList.add('active');
                }
            });
            // Section switch
            document.querySelectorAll('.section-view').forEach(function(el) { el.classList.remove('active'); });
            var targetSec = document.getElementById(sectionId);
            if(targetSec) targetSec.classList.add('active');
            if(sectionId === 'qrManagement') filterQRTable();
            if(sectionId === 'history') { loadAuditFromServer(true); }
            if(sectionId === 'monthlyOrders') { renderHistoryPOTableWithFilter(allData.pendingPOs); }
            if(sectionId === 'settings') { setTimeout(function(){ syncMasterDataTags(); }, 50); }
        }

        function parseThaiDate(dateStr) {
        if(!dateStr || dateStr === '-') return null;
    
           // ตัดเอาเฉพาะส่วนวันที่ (DD/MM/YYYY) ไม่เอาส่วนของเวลามาคำนวณ Timezone ซ้ำซ้อน
             const parts = String(dateStr).trim().split(' '); 
           if(parts.length === 0) return null;
    
              const dmy = parts[0].split('/'); 
               if(dmy.length !== 3) return null;
    
              let day = parseInt(dmy[0], 10); 
             let month = parseInt(dmy[1], 10) - 1; 
             let year = parseInt(dmy[2], 10);
    
               // จัดการเรื่องปี พ.ศ. และ ค.ศ. ให้ถูกต้องและคงที่
              if (allData.settings?.dateFormat === 'EN') { 
        if(year < 100) year += 2000; 
    } else { 
        if(year < 100) year += 2500; 
        if(year > 2400) year -= 543; 
    }
    
    // ใช้เวลาเที่ยงวัน (12:00) เป็นเกณฑ์ในการเปรียบเทียบ เพื่อป้องกันปัญหาเรื่องเขตเวลาปัดวันข้ามไปมา
    return new Date(year, month, day, 12, 0, 0, 0);
    }

        function getFormattedDate(dateStr) {
            const d = dateStr ? new Date(dateStr) : new Date();
            const day = String(d.getDate()).padStart(2, '0');
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const isEn = allData.settings?.dateFormat === 'EN';
            const year = isEn ? d.getFullYear() : String(d.getFullYear() + 543).slice(-2);
            const hours = String(d.getHours()).padStart(2, '0');
            const minutes = String(d.getMinutes()).padStart(2, '0');
            return `${day}/${month}/${year} ${hours}:${minutes}`;
        }

        function formatNumber(num) {
            try {
                if (num === null || num === undefined || num === '') return num;
                let parsed = Number(num); if (isNaN(parsed)) return num;
                const dec = parseInt(allData.settings?.decimalPlaces) || 0; return parsed.toFixed(dec);
            } catch(e) { return num; }
        }

        function getItemCategory(item) {
            if (!item) return '';
            let cat = item.category || item.Category || item.group || item.Group || item.cat || item['หมวดหมู่'] || item.type || item.Type;
            if (cat !== undefined && cat !== null && String(cat).trim() !== '') return String(cat).trim();
            for (let key in item) {
                let lowerKey = String(key).toLowerCase().trim();
                if (['category','group','หมวดหมู่','type','cat'].includes(lowerKey)) {
                    if (item[key] !== undefined && item[key] !== null) return String(item[key]).trim();
                }
            }
            return '';
        }

        function getCombinedCategories(list) {
            let cats = [];
            if (allData.settings && allData.settings.categories) {
                let parts = allData.settings.categories.split(',');
                parts.forEach(p => { let s = p.trim(); if (s !== '') { if (s.includes(':')) cats.push(s.split(':')[0].trim()); else cats.push(s); } });
            }
            if (list && Array.isArray(list)) {
                const uniqueCats = [...new Set(list.map(item => getItemCategory(item)))].filter(c => c && c !== 'undefined' && String(c).trim() !== '');
                cats = cats.concat(uniqueCats);
            }
            return [...new Set(cats)].sort();
        }

        function getCombinedLocations(list) {
            let locs = [];
            if (allData.settings && allData.settings.locations) {
                locs = allData.settings.locations.split(',').map(s => s.trim()).filter(s => s !== '');
            }
            if (list && Array.isArray(list)) {
                const uniqueLocs = [...new Set(list.map(item => item.location))].filter(c => c && c !== 'undefined' && String(c).trim() !== '');
                locs = locs.concat(uniqueLocs);
            }
            return [...new Set(locs)].sort();
        }

        function populateCategoryFilter(items) {
            try {
                const selectItem = document.getElementById('itemCategoryFilter');
                if(selectItem) {
                    const currentVal = selectItem.value;
                    selectItem.innerHTML = '<option value="">📁 ทุกหมวดหมู่</option>';
                    const uniqueCats = [...new Set(items.map(i => getItemCategory(i)))].filter(c => c && c !== 'undefined');
                    uniqueCats.sort().forEach(cat => { let opt = document.createElement('option'); opt.value = cat; opt.textContent = cat; selectItem.appendChild(opt); });
                    selectItem.value = currentVal;
                }
            } catch(e) { console.error(e); }
        }

        function populateCategoryFilterTools(tools) {
            try {
                const selectTool = document.getElementById('toolCategoryFilter');
                if(selectTool) {
                    const currentVal2 = selectTool.value;
                    selectTool.innerHTML = '<option value="">📁 ทุกหมวดหมู่</option>';
                    const uniqueCats = [...new Set(tools.map(t => getItemCategory(t)))].filter(c => c && c !== 'undefined');
                    uniqueCats.sort().forEach(cat => { let opt = document.createElement('option'); opt.value = cat; opt.textContent = cat; selectTool.appendChild(opt); });
                    selectTool.value = currentVal2;
                }
            } catch(e) { console.error(e); }
        }

        function populateQRCategoryFilter(items, tools) {
            try {
                const selectQR = document.getElementById('qrCategoryFilter');
                if(selectQR) {
                    const currentVal = selectQR.value;
                    selectQR.innerHTML = '<option value="">📁 ทุกหมวดหมู่</option>';
                    const allList = items.concat(tools);
                    const uniqueCats = [...new Set(allList.map(i => getItemCategory(i)))].filter(c => c && c !== 'undefined' && String(c).trim() !== '');
                    uniqueCats.sort().forEach(cat => { 
                        let opt = document.createElement('option'); 
                        opt.value = cat; 
                        opt.textContent = cat; 
                        selectQR.appendChild(opt); 
                    });
                    selectQR.value = currentVal;
                }
            } catch(e) { console.error(e); }
        }

        function checkLogin() {
            const urlParams = new URLSearchParams(window.location.search);
            const uid = urlParams.get('uid');
            
            document.getElementById('loading').style.display = 'flex';
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(data => { 
                    document.getElementById('loading').style.display = 'none';
                    if(data && data.settings) applySettingsUI(data.settings); 
                    allData = data || {}; 
                    
                    if (uid) { 
                        currentUserProfile.uid = uid;
                        if (data && data.users) {
                            const u = data.users.find(x => x.userId === uid);
                            if (u) { currentUserProfile.name = u.name; currentUserProfile.role = u.role; }
                        }
                        document.getElementById('loginScreen').style.display = 'none'; 
                        onDataLoaded(data); 
                    } else { 
                        document.getElementById('loginScreen').style.display = 'flex';
                        populateLoginUsers(data && data.users ? data.users : []);
                    }
                }).withFailureHandler(err => {
                    console.error('GAS Error:', err);
                    document.getElementById('loading').style.display = 'none';
                    document.getElementById('loginScreen').style.display = 'flex';
                    allData = createMockData();
                    populateLoginUsers(allData.users || []);
                }).getInventoryData();
            } else {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('loginScreen').style.display = 'flex';
                allData = createMockData();
                populateLoginUsers(allData.users || []);
            }
        }
        
        function createMockData() {
            return { 
                items: [
                    {code: 'IT-001', name: 'น็อต M8 x 1.5', category: 'Hardware', location: 'ตู้ A ชั้น 2', stock: 150, min: 50, unit: 'ตัว'}
                ], 
                tools: [
                    {code: 'TL-001', name: 'สว่านไร้สาย 18V', category: 'Power Tools', location: 'ตู้เครื่องมือช่าง', stock: 3, min: 2, unit: 'ชุด'}
                ], 
                history: [], activeBorrows: [], pendingPOs: [], 
                users: [{userId: 'u_admin123', name: 'Test Admin', role: 'admin'}], 
                settings: { prefixItem: 'IT', prefixTool: 'TL', sysName: 'คลังอะไหล่เมาท์เทน', themeColor: '#4f46e5' } 
            };
        }

        function populateLoginUsers(users) {
            const select = document.getElementById('loginUid');
            if(!select) {
                console.warn('loginUid element not found');
                return;
            }
            if(!users || users.length === 0) {
                select.innerHTML = '<option value="">-- ไม่พบผู้ใช้ --</option>';
                return;
            }
            select.innerHTML = '<option value="">-- เลือกระบุตัวตน --</option>';
            users.filter(u => u.role === 'admin' || u.role === 'user').forEach(u => {
                let opt = document.createElement('option');
                opt.value = u.userId;
                opt.text = u.name + (u.role === 'admin' ? ' (Admin)' : ' (User)');
                select.appendChild(opt);
            });
        }

        function handleLogin(e) {
            e.preventDefault();
            const uid = document.getElementById('loginUid').value;
            const pin = document.getElementById('loginPin').value;
            const btn = document.querySelector('#loginForm button');
            if(!uid) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเลือกชื่อผู้ใช้งานของคุณ', confirmButtonColor: 'var(--primary-color)'});

            btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> กำลังตรวจสอบ...';

            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(isValid) {
                    btn.disabled = false; btn.innerHTML = 'เข้าสู่ระบบ';
                    if (isValid) {
                        currentUserProfile.uid = uid;
                        // resolve ชื่อและ role จาก allData.users ทันที
                        if (allData.users) {
                            const u = allData.users.find(x => x.userId === uid);
                            if (u) { currentUserProfile.name = u.name; currentUserProfile.role = u.role; }
                        }
                        document.getElementById('loginError').classList.add('d-none');
                        document.getElementById('loginScreen').style.display = 'none';
                        writeAudit('LOGIN', `เข้าสู่ระบบสำเร็จ — ${currentUserProfile.name} (${currentUserProfile.role})`);
                        onDataLoaded(allData);
                        resetSessionTimer(); setupAutoRefresh(allData.settings);
                    } else { document.getElementById('loginError').classList.remove('d-none'); }
                }).withFailureHandler(function(err) {
                    btn.disabled = false; btn.innerHTML = 'เข้าสู่ระบบ'; 
                    Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: 'ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้', confirmButtonColor: 'var(--primary-color)'});
                }).webVerifyUserPin(uid, pin);
            } else {
                if(pin === '1234' || pin === 'admin') { 
                    currentUserProfile.uid = uid;
                    if (allData.users) {
                        const u = allData.users.find(x => x.userId === uid);
                        if (u) { currentUserProfile.name = u.name; currentUserProfile.role = u.role; }
                    }
                    document.getElementById('loginScreen').style.display = 'none'; writeAudit('LOGIN', `เข้าสู่ระบบสำเร็จ — ${currentUserProfile.name} (${currentUserProfile.role})`); onDataLoaded(allData); 
                } else { btn.disabled = false; btn.innerHTML = 'เข้าสู่ระบบ'; document.getElementById('loginError').classList.remove('d-none'); }
            }
        }

        function updateWebPin() {
            const pin1 = document.getElementById('newWebPin').value; const pin2 = document.getElementById('confirmWebPin').value;
            if(!pin1 || !pin2) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณากรอกรหัสให้ครบ'});
            if(pin1 !== pin2) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'รหัสผ่านไม่ตรงกัน'});
            if(!currentUserProfile.uid) return Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: 'ไม่พบรหัสประจำตัว กรุณาออกจากระบบแล้วเข้าใหม่'});
            
            document.getElementById('loading').style.display = 'flex';
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(res && res.success) { 
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'เปลี่ยนรหัสผ่านส่วนตัวของคุณสำเร็จ!', timer: 2000, showConfirmButton: false}); 
                        document.getElementById('newWebPin').value = ''; document.getElementById('confirmWebPin').value = ''; 
                    } else { Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: (res ? res.error : 'Unknown')}); }
                }).webUpdateUserPin(currentUserProfile.uid, pin1);
            } else {
                setTimeout(() => {
                    document.getElementById('loading').style.display = 'none';
                    Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'เปลี่ยนรหัสผ่านสำเร็จ!', timer: 2000, showConfirmButton: false});
                }, 500);
            }
        }

        function toggleDarkModePreview(isDark) {
            if(isDark) document.body.classList.add('dark-mode'); else document.body.classList.remove('dark-mode');
        }

        function applySettingsUI(s) {
            if (!s) return;
            if (s.themeColor) document.documentElement.style.setProperty('--primary-color', s.themeColor);
            if (s.sysName) { document.title = s.sysName; document.querySelectorAll('.sys-name-display').forEach(el => el.innerText = s.sysName); }
            if (s.darkMode) document.body.classList.add('dark-mode'); else document.body.classList.remove('dark-mode');
            
            if (s.sysLogo) {
                document.querySelectorAll('.sys-logo-display').forEach(el => { el.src = s.sysLogo; el.style.display = 'block'; });
                document.querySelectorAll('.sys-icon-display').forEach(el => { el.style.display = 'none'; });
            } else {
                document.querySelectorAll('.sys-logo-display').forEach(el => { el.style.display = 'none'; });
                document.querySelectorAll('.sys-icon-display').forEach(el => { el.style.display = 'inline-block'; });
            }
            if (s.adminContact) {
                const ac = document.getElementById('adminContactDisplay');
                if(ac) ac.innerHTML = `<i class="fas fa-shield-alt"></i> ระบบความปลอดภัยระดับองค์กร<br>${s.adminContact}`;
            }

            if(document.getElementById('setSysName')) document.getElementById('setSysName').value = s.sysName || '';
            if(document.getElementById('setSysLogo')) { document.getElementById('setSysLogo').value = s.sysLogo || ''; previewLogo(s.sysLogo || ''); }
            if(document.getElementById('setSysCredit')) document.getElementById('setSysCredit').value = s.sysCredit || '';
            
            const creditDisplay = document.getElementById('sysCreditDisplay');
            if (creditDisplay) creditDisplay.innerText = s.sysCredit || '';

            if(document.getElementById('setThemeColor')) document.getElementById('setThemeColor').value = s.themeColor || '#4f46e5';
            if(document.getElementById('setDarkMode')) document.getElementById('setDarkMode').checked = !!s.darkMode;
            if(document.getElementById('setAutoRefresh')) { document.getElementById('setAutoRefresh').checked = !!s.autoRefresh; toggleAutoRefresh(!!s.autoRefresh); }
            if(document.getElementById('setRefreshInterval')) document.getElementById('setRefreshInterval').value = s.refreshInterval || 3;
            if(document.getElementById('setRowsPerPage')) document.getElementById('setRowsPerPage').value = s.rowsPerPage || 100;
            if(document.getElementById('setDateFormat')) document.getElementById('setDateFormat').value = s.dateFormat || 'TH';
            if(document.getElementById('setAutoApprove')) document.getElementById('setAutoApprove').checked = !!s.autoApprove;
            if(document.getElementById('setMaxBorrowDays')) document.getElementById('setMaxBorrowDays').value = s.maxBorrowDays || 7;
            if(document.getElementById('setReqRemark')) document.getElementById('setReqRemark').checked = !!s.reqRemark;
            if(document.getElementById('setDecimalPlaces')) document.getElementById('setDecimalPlaces').value = s.decimalPlaces || 0;
            if(document.getElementById('setLineNotify')) document.getElementById('setLineNotify').value = s.lineNotifyToken || '';
            if(document.getElementById('setDailyDigest')) document.getElementById('setDailyDigest').value = s.dailyDigestTime || '08:30';
            if(document.getElementById('setSessionTime')) document.getElementById('setSessionTime').value = s.sessionTimeout || 30;
            if(document.getElementById('setAdminContact')) document.getElementById('setAdminContact').value = s.adminContact || '';
            if(document.getElementById('setPrefixItem')) document.getElementById('setPrefixItem').value = s.prefixItem || 'IT';
            if(document.getElementById('setPrefixTool')) document.getElementById('setPrefixTool').value = s.prefixTool || 'TL';
            if(document.getElementById('setWelcomeMsg')) document.getElementById('setWelcomeMsg').value = s.welcomeMsg || '';
            if(document.getElementById('setManualUrl')) document.getElementById('setManualUrl').value = s.manualUrl || '';
            
            if(document.getElementById('setCategories')) { document.getElementById('setCategories').value = s.categories || ''; syncMasterDataTags(); }
            if(document.getElementById('setLocations')) { document.getElementById('setLocations').value = s.locations || ''; syncMasterDataTags(); }

            if (s.reqRemark) {
                const txReq = document.getElementById('txRemarkReq'); if(txReq) txReq.classList.remove('d-none'); 
                const txRem = document.getElementById('txRemark'); if(txRem) txRem.required = true;
                const bwReq = document.getElementById('bwRemarkReq'); if(bwReq) bwReq.classList.remove('d-none'); 
                const bwRem = document.getElementById('borrowRemark'); if(bwRem) bwRem.required = false;
            } else {
                const txReq = document.getElementById('txRemarkReq'); if(txReq) txReq.classList.add('d-none'); 
                const txRem = document.getElementById('txRemark'); if(txRem) txRem.required = false;
                const bwReq = document.getElementById('bwRemarkReq'); if(bwReq) bwReq.classList.add('d-none'); 
                const bwRem = document.getElementById('borrowRemark'); if(bwRem) bwRem.required = false;
            }
            setupAutoRefresh(s);
        }

        function syncMasterDataTags() {
            const catInput = document.getElementById('setCategories');
            const locInput = document.getElementById('setLocations');

            const allList = (allData.items || []).concat(allData.tools || []);

            // --- Categories: รวม settings + ดึง unique จาก items & tools จริง ---
            if (catInput) {
                const savedCats = (allData.settings?.categories || '')
                    .split(',').map(s => s.trim()).filter(s => s);

                const sheetCats = [...new Set(
                    allList.map(i => String(i.category || '').trim())
                           .filter(s => s && s !== 'undefined')
                )];

                // เก็บ prefix mapping จาก settings (format "ชื่อ:PREFIX") ไว้ก่อน
                const prefixMap = {};
                savedCats.forEach(s => {
                    if (s.includes(':')) {
                        const [name, prefix] = s.split(':');
                        prefixMap[name.trim()] = prefix.trim();
                    }
                });

                // รวม category ทั้งหมด (ใส่ prefix mapping กลับถ้ามี)
                const allCatNames = [...new Set([
                    ...savedCats.map(s => s.includes(':') ? s.split(':')[0].trim() : s),
                    ...sheetCats
                ])].sort();

                const combined = allCatNames.map(name =>
                    prefixMap[name] ? `${name}:${prefixMap[name]}` : name
                );

                catInput.value = combined.join(', ');
                if (allData.settings) allData.settings.categories = catInput.value;
            }

            // --- Locations: รวม settings + ดึง unique จาก items & tools จริง ---
            if (locInput) {
                const savedLocs = (allData.settings?.locations || '')
                    .split(',').map(s => s.trim()).filter(s => s);

                const sheetLocs = [...new Set(
                    allList.map(i => String(i.location || '').trim())
                           .filter(s => s && s !== 'undefined')
                )];

                const combined = [...new Set([...savedLocs, ...sheetLocs])].sort();
                locInput.value = combined.join(', ');
                if (allData.settings) allData.settings.locations = locInput.value;
            }

            if (catInput) renderTagChips('category', catInput.value);
            if (locInput) renderTagChips('location', locInput.value);
        }
     function renderTagChips(type, csvString) {
    const containerId = type === 'category' ? 'categoriesTagContainer' : 'locationsTagContainer';
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '';
    const items = csvString.split(',').map(s => s.trim()).filter(s => s !== '');
    if (items.length === 0) { 
        container.innerHTML = '<span class="text-muted small opacity-50 py-1">ยังไม่มีรายการ...</span>'; 
        return; 
    }

    items.forEach(item => {
        const chip = document.createElement('span');
        const safeItem = item.replace(/'/g, "\\'");

        if (type === 'category' && item.includes(':')) {
            // มี prefix mapping เช่น "เครื่องเป่า:BL"
            const [catName, catPrefix] = item.split(':');
            chip.className = 'tag-chip';
            chip.innerHTML = `
                <i class="fas fa-tag" style="font-size:0.7rem;opacity:0.7;"></i>
                ${catName.trim()}
                <span class="badge bg-dark font-monospace ms-1 px-2" style="font-size:0.7rem;">${catPrefix.trim()}</span>
                <button type="button" class="tag-chip-remove" onclick="removeTagChip('${type}','${safeItem}')">×</button>
            `;
        } else if (type === 'location') {
            chip.className = 'tag-chip tag-location';
            chip.innerHTML = `
                <i class="fas fa-map-marker-alt" style="font-size:0.7rem;opacity:0.7;"></i>
                ${item}
                <button type="button" class="tag-chip-remove" onclick="removeTagChip('${type}','${safeItem}')">×</button>
            `;
        } else {
            chip.className = 'tag-chip';
            chip.innerHTML = `
                <i class="fas fa-tag" style="font-size:0.7rem;opacity:0.7;"></i>
                ${item}
                <button type="button" class="tag-chip-remove" onclick="removeTagChip('${type}','${safeItem}')">×</button>
            `;
        }
        container.appendChild(chip);
    });
}

        

        function removeTagChip(type, itemToRemove) {
            const hiddenInputId = type === 'category' ? 'setCategories' : 'setLocations';
            const hiddenInput = document.getElementById(hiddenInputId);
            if (!hiddenInput) return;
            const updated = hiddenInput.value.split(',').map(s => s.trim()).filter(s => s && s !== itemToRemove);
            hiddenInput.value = updated.join(', ');
            renderTagChips(type, hiddenInput.value);
        }

        function addTagFromInput(type) {
            const inputId = type === 'category' ? 'categoryTagInput' : 'locationTagInput';
            const hiddenInputId = type === 'category' ? 'setCategories' : 'setLocations';
            const inputEl = document.getElementById(inputId); const hiddenInput = document.getElementById(hiddenInputId);
            if (!inputEl || !hiddenInput) return;

            const newItems = inputEl.value.split(',').map(s => s.trim()).filter(s => s);
            if (newItems.length === 0) return;

            const current = hiddenInput.value.split(',').map(s => s.trim()).filter(s => s);
            const currentNames = current.map(s => (s.includes(':') ? s.split(':')[0].trim() : s));

            newItems.forEach(item => {
                const itemName = item.includes(':') ? item.split(':')[0].trim() : item;
                if (!currentNames.includes(itemName)) { current.push(item); currentNames.push(itemName); }
            });

            hiddenInput.value = current.join(', ');
            renderTagChips(type, hiddenInput.value);
            inputEl.value = ''; inputEl.focus();
        }

        document.addEventListener('DOMContentLoaded', function() {
            ['categoryTagInput', 'locationTagInput'].forEach(function(id) {
                const el = document.getElementById(id);
                if (!el) return;
                el.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); const type = id === 'categoryTagInput' ? 'category' : 'location'; if (e.key === ',') el.value = el.value.replace(/,\s*$/, ''); addTagFromInput(type); }
                });
            });
        });

        function saveAllSettings() {
            const payload = {
                sysName: document.getElementById('setSysName').value.trim(), 
                sysLogo: document.getElementById('setSysLogo').value.trim(), 
                sysCredit: document.getElementById('setSysCredit') ? document.getElementById('setSysCredit').value.trim() : '', 
                themeColor: document.getElementById('setThemeColor').value, 
                darkMode: document.getElementById('setDarkMode').checked,
                autoRefresh: document.getElementById('setAutoRefresh') ? document.getElementById('setAutoRefresh').checked : false, 
                refreshInterval: document.getElementById('setRefreshInterval') ? parseInt(document.getElementById('setRefreshInterval').value) : 3,
                rowsPerPage: document.getElementById('setRowsPerPage').value, 
                dateFormat: document.getElementById('setDateFormat').value, 
                autoApprove: document.getElementById('setAutoApprove').checked, 
                maxBorrowDays: document.getElementById('setMaxBorrowDays').value,
                reqRemark: document.getElementById('setReqRemark').checked, 
                decimalPlaces: document.getElementById('setDecimalPlaces').value, 
                lineNotifyToken: document.getElementById('setLineNotify').value.trim(), 
                dailyDigestTime: document.getElementById('setDailyDigest').value,
                sessionTimeout: document.getElementById('setSessionTime').value, 
                adminContact: document.getElementById('setAdminContact').value.trim(), 
                prefixItem: document.getElementById('setPrefixItem').value.trim().toUpperCase(), 
                prefixTool: document.getElementById('setPrefixTool').value.trim().toUpperCase(),
                welcomeMsg: document.getElementById('setWelcomeMsg').value, 
                manualUrl: document.getElementById('setManualUrl').value.trim(),
                categories: document.getElementById('setCategories') ? document.getElementById('setCategories').value.trim() : '', 
                locations: document.getElementById('setLocations') ? document.getElementById('setLocations').value.trim() : '',
                user: currentUserProfile.name, 
                userId: currentUserProfile.uid
            };
            if(!payload.sysName || !payload.prefixItem || !payload.prefixTool) return Swal.fire({icon: 'warning', title: 'ข้อมูลไม่ครบ', text: 'กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน (ชื่อ, ตัวย่อ)'});
            
            document.getElementById('loading').style.display = 'flex';
            if (typeof google !== 'undefined' && google.script && google.script.run && google.script.run.webSaveSettings) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(res && !res.success) { Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); } 
                    else { writeAudit('SETTINGS', `บันทึกการตั้งค่าระบบ — ชื่อ: ${payload.sysName} | ธีม: ${payload.themeColor}`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกการตั้งค่าสำเร็จ!', timer: 2000, showConfirmButton: false}); allData.settings = { ...allData.settings, ...payload }; applySettingsUI(allData.settings); loadData(true); }
                }).webSaveSettings(payload);
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('SETTINGS', `บันทึกการตั้งค่าระบบ (Demo) — ชื่อ: ${payload.sysName}`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกการตั้งค่าสำเร็จ!', timer: 2000, showConfirmButton: false}); allData.settings = { ...allData.settings, ...payload }; applySettingsUI(allData.settings); }, 500); }
        }

        function applyPermissions() {
            const isAdmin = (currentUserProfile.role === 'admin');
            const menuSettings = document.getElementById('menu-settings');
            if (menuSettings) menuSettings.style.display = isAdmin ? 'block' : 'none';
            document.querySelectorAll('.admin-only-element').forEach(el => {
                if (!isAdmin) {
                    el.style.display = 'none';
                } else {
                    // li และ block-level elements ใช้ block, ส่วน inline ใช้ inline-block
                    const tag = el.tagName.toLowerCase();
                    el.style.display = (tag === 'li' || tag === 'div' || tag === 'tr') ? '' : 'inline-block';
                }
            });
        }

        function onDataLoaded(data) {
            try {
                data = data || {}; data.items = data.items || []; data.tools = data.tools || []; data.history = data.history || []; data.activeBorrows = data.activeBorrows || []; data.pendingPOs = data.pendingPOs || []; data.users = data.users || []; data.settings = data.settings || {};
                if (data.error) Swal.fire({icon: 'error', title: 'พบปัญหาการเชื่อมต่อ', text: data.error});
                allData = data; 
                selectedQRCodes.clear();
                updateSelectedQRCount();
                
                document.getElementById('lastUpdate').innerText = getFormattedDate();

                applySettingsUI(allData.settings);
                
                if (currentUserProfile.uid && allData.users) { let u = allData.users.find(x => x.userId === currentUserProfile.uid); if (u) { currentUserProfile.name = u.name; currentUserProfile.role = u.role; } }
                const profileDisplay = document.getElementById('userProfileName'); if(profileDisplay) profileDisplay.innerText = currentUserProfile.name;
                const pinNameDisplay = document.getElementById('pinUserNameDisplay'); if(pinNameDisplay) pinNameDisplay.innerText = currentUserProfile.name;

                applyPermissions();
                
                setTimeout(() => {
                    populateCategoryFilter(data.items); populateCategoryFilterTools(data.tools); 
                    populateQRCategoryFilter(data.items, data.tools);
                    syncMasterDataTags();
                }, 10);

                let damagedSummary = {};
                for (let i = data.history.length - 1; i >= 0; i--) {
                    let log = data.history[i];
                    let qty = parseFloat(String(log.amount).replace(/[^0-9.]/g, '')) || 0;
                    let act = String(log.action).trim().toLowerCase();
                    let userStr = String(log.user || '');
                    if (act === 'แจ้งชำรุด' || (act === 'เบิก' && userStr.includes('ชำรุด'))) {
                        if (!damagedSummary[log.code]) { damagedSummary[log.code] = { code: log.code, name: log.itemName, unit: log.unit, qty: 0, latestDate: log.time }; }
                        damagedSummary[log.code].qty += qty; damagedSummary[log.code].latestDate = log.time;
                    }
                    if (act === 'ซ่อมแซมแล้ว' || (act === 'รับเข้า' && userStr.includes('ซ่อมแซมแล้ว'))) {
                        if (damagedSummary[log.code]) damagedSummary[log.code].qty -= qty;
                    }
                }
                
                const currentlyDamaged = Object.values(damagedSummary).filter(item => item.qty > 0);
                let lowStockCount = data.items.filter(i => i.stock <= i.min).length + data.tools.filter(i => i.stock <= i.min).length;
                
                animateValue("count-items", 0, data.items.length, 500); animateValue("count-tools", 0, data.tools.length, 500); animateValue("count-low", 0, lowStockCount, 500); animateValue("count-logs", 0, data.history.filter(h => h.time.includes(getFormattedDate().split(' ')[0])).length, 500);

                const toolCodes = new Set(data.tools.map(t => t.code));
                const activeToolBorrows = data.activeBorrows.filter(b => toolCodes.has(b.itemCode));
                const activeItemBorrows = data.activeBorrows.filter(b => !toolCodes.has(b.itemCode)); 

                try { renderDashboardTx(data.history); } catch(e) { console.warn('renderDashboardTx error:', e); }
                try { renderDashboardDamaged(currentlyDamaged); } catch(e) { console.warn('renderDashboardDamaged error:', e); }
                try { renderDashboardChart(data); } catch(e) { console.warn('renderDashboardChart error:', e); }
                try { renderLowStockTables(data.items, data.tools); } catch(e) { console.warn('renderLowStockTables error:', e); }
                try { renderCategorySummary(data); } catch(e) { console.warn('renderCategorySummary error:', e); }
                try { renderActiveBorrows(); } catch(e) { console.warn('renderActiveBorrows error:', e); }

                setTimeout(() => {
                    filterTable('itemsTable'); filterTable('toolsTable'); filterHistoryTable(); filterTxTable();
                }, 50);

                setTimeout(() => {
                    renderMonthlyOrders(currentlyDamaged, data.items.filter(i => i.stock <= i.min), data.pendingPOs);
                    renderBorrowedTable('borrowedItemsTableMain', activeItemBorrows); renderBorrowedTable('borrowedToolsTableMain', activeToolBorrows); 
                    renderDamagedTools(currentlyDamaged); filterUsersTable();
                    renderHistoryPOTableWithFilter(data.pendingPOs);
                    renderSummaryPOTable(data.pendingPOs);
                    if(document.getElementById('qrManagement').classList.contains('active')) filterQRTable();
                    // Audit: silent refresh = merge เฉพาะรายการใหม่, ครั้งแรก = โหลดเต็ม
                    if(document.getElementById('history').classList.contains('active')) {
                        loadAuditFromServer(false); // false = อย่า force reload
                    }
                }, 100);

            } catch(e) { console.error("onDataLoaded Error: ", e); }
        }
