/* =================================================
   app.js — UI rendering, navigation, interactions
   คลังอะไหล่เมาท์เทน | C-FACTORY WMS
   ================================================= */

        function loadData(isSilent = false) {
            if (isFetchingData) return;
            isFetchingData = true;

            if (!isSilent) document.getElementById('loading').style.display = 'flex';
            else { const syncInd = document.getElementById('syncIndicator'); if(syncInd) syncInd.classList.remove('d-none'); }
            
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler((data) => {
                    isFetchingData = false;
                    if(!isSilent) {
                        document.getElementById('loading').style.display = 'none';
                        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'อัปเดตข้อมูลล่าสุดแล้ว', showConfirmButton: false, timer: 1500 });
                    } else { 
                        const syncInd = document.getElementById('syncIndicator'); if(syncInd) syncInd.classList.add('d-none'); 
                    }
                    onDataLoaded(data);
                }).withFailureHandler((e) => {
                    isFetchingData = false;
                    if(!isSilent) {
                        document.getElementById('loading').style.display = 'none';
                        Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: e});
                    } else { 
                        const syncInd = document.getElementById('syncIndicator'); if(syncInd) syncInd.classList.add('d-none'); 
                    }
                }).getInventoryData();
            } else {
                setTimeout(() => { 
                    isFetchingData = false;
                    if(!isSilent) {
                        document.getElementById('loading').style.display = 'none'; 
                        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'อัปเดตข้อมูลแล้ว', showConfirmButton: false, timer: 1500 });
                    } else { 
                        const syncInd = document.getElementById('syncIndicator'); if(syncInd) syncInd.classList.add('d-none'); 
                    }
                    onDataLoaded(allData); 
                }, 500);
            }
        }

        function animateValue(id, start, end, duration) {
            const obj = document.getElementById(id); if(!obj) return;
            // ถ้าค่าเท่าเดิม ไม่ต้อง animate ซ้ำ
            if (parseInt(obj.innerHTML) === end) return;
            let startTimestamp = null;
            const step = (timestamp) => { 
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1); 
                obj.innerHTML = Math.floor(progress * (end - start) + start); 
                if (progress < 1) window.requestAnimationFrame(step); 
            }; window.requestAnimationFrame(step);
        }

         function renderDashboardTx(history) {
            try {
           const tbody = document.querySelector('#dashTxTable tbody'); 
           if(!tbody) return; 
        
          // แก้จุดนี้: สั่งล้างข้อมูลเก่าในตารางกิจกรรมล่าสุดบน Dashboard ให้สะอาดก่อนวาดใหม่
         tbody.innerHTML = ''; 
         
         const filtered = history.filter(log => ['รับเข้า', 'เบิก', 'new item', 'ซ่อมแซมแล้ว', 'แจ้งชำรุด'].includes(String(log.action).trim().toLowerCase())).slice(0, 8);
         if (filtered.length === 0) { 
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">ไม่มีประวัติทำรายการล่าสุด</td></tr>'; 
            return; 
        }
         filtered.forEach(log => {
            const tr = document.createElement('tr');
            const actLower = String(log.action).trim().toLowerCase();
            const isOut = (actLower === 'เบิก' || actLower === 'แจ้งชำรุด');
            const badgeClass = isOut ? 'bg-danger bg-opacity-10 text-danger' : 'bg-success bg-opacity-10 text-success';
            const icon = isOut ? 'fa-arrow-down' : 'fa-arrow-up';
            const txtColor = isOut ? 'text-danger' : 'text-success';
            const displayAction = actLower === 'new item' ? 'รับเข้า (ใหม่)' : log.action;
            const displayUser = log.user ? String(log.user).replace(/\[.*?\]/g, '').replace(' (แจ้งชำรุด)', '').replace(' (ซ่อมแซมแล้ว)', '') : 'ไม่ระบุ';
            const remark = log.remark ? String(log.remark).trim() : '';
            tr.innerHTML = `
                <td class="text-muted small py-3">${(log.time || '').split(' ')[1] || (log.time || '')}</td>
                <td class="text-center py-3"><span class="badge ${badgeClass} rounded-pill w-100 py-2"><i class="fas ${icon} me-1"></i> ${displayAction}</span></td>
                <td class="fw-bold text-dark py-3">${log.itemName} <span class="badge bg-light text-secondary border ms-1 font-monospace fw-normal">${log.code}</span></td>
                <td class="text-center fw-bold ${txtColor} py-3">${log.amount}</td>
                <td class="text-muted small py-3"><i class="fas fa-user-circle me-1"></i> ${displayUser}</td>
                <td class="text-muted small py-3">${remark}</td>
            `;
            tbody.appendChild(tr);
        });
    } catch(e) { console.error(e); }
}

        

        function renderDashboardDamaged(damagedItems) {
            try {
                const tbody = document.querySelector('#dashDamagedTable tbody'); if(!tbody) return; tbody.innerHTML = '';
                if (damagedItems.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="4" class="text-center py-5 text-success"><i class="fas fa-check-circle fs-3 d-block mb-2"></i>เยี่ยม! ไม่มีเครื่องมือรอซ่อม</td></tr>';
                    return;
                }
                damagedItems.slice(0, 4).forEach(item => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td class="text-muted font-monospace py-3">${item.code}</td><td class="fw-bold text-dark py-3">${item.name}</td><td class="text-center py-3"><span class="badge bg-danger rounded-pill fs-6">${formatNumber(item.qty)}</span></td><td class="text-end py-3"><button class="btn btn-sm btn-light text-primary border" onclick="goTo('monthlyOrders'); setTimeout(() => document.querySelector('button[data-bs-target=\\'#tabToolsOrders\\']').click(), 200);"><i class="fas fa-wrench"></i></button></td>`;
                    tbody.appendChild(tr);
                });
            } catch(e) { console.error(e); }
        }


        function renderLowStockTables(items, tools) {
            try {
                const itBody = document.querySelector('#dashLowStockItems tbody');
                const tlBody = document.querySelector('#dashLowStockTools tbody');
                if (itBody) itBody.innerHTML = '';
                if (tlBody) tlBody.innerHTML = '';

                const lowItems = (items || []).filter(i => Number(i.stock) <= Number(i.min)).sort((a,b) => (Number(a.stock)-Number(a.min)) - (Number(b.stock)-Number(b.min)));
                const lowTools = (tools || []).filter(t => Number(t.stock) <= Number(t.min)).sort((a,b) => (Number(a.stock)-Number(a.min)) - (Number(b.stock)-Number(b.min)));

                if (itBody) {
                    if (lowItems.length === 0) itBody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">ไม่มีอะไหล่ต้องสั่งเติม</td></tr>';
                    else lowItems.forEach(i => { const tr = document.createElement('tr'); tr.innerHTML = `<td class="font-monospace">${i.code}</td><td class="fw-bold">${i.name}</td><td class="text-center">${formatNumber(i.stock)}</td><td class="text-center">${formatNumber(i.min)}</td><td>${i.unit||''}</td>`; itBody.appendChild(tr); });
                }
                if (tlBody) {
                    if (lowTools.length === 0) tlBody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">ไม่มีเครื่องมือต้องซ่อม/เติม</td></tr>';
                    else lowTools.forEach(t => { const tr = document.createElement('tr'); tr.innerHTML = `<td class="font-monospace">${t.code}</td><td class="fw-bold">${t.name}</td><td class="text-center">${formatNumber(t.stock)}</td><td class="text-center">${formatNumber(t.min)}</td><td>${t.unit||''}</td>`; tlBody.appendChild(tr); });
                }
            } catch(e) { console.error(e); }
        }

        function renderCategorySummary(data) {
            try {
                const body = document.querySelector('#dashCategorySummary tbody'); if(!body) return; body.innerHTML = '';
                const map = {};
                (data.items || []).forEach(i => { const c = getItemCategory(i)||'ไม่ระบุ'; map[c] = map[c] || {count:0, total:0}; map[c].count++; map[c].total += Number(i.stock)||0; });
                (data.tools || []).forEach(t => { const c = getItemCategory(t)||'ไม่ระบุ'; map[c] = map[c] || {count:0, total:0}; map[c].count++; map[c].total += Number(t.stock)||0; });
                const rows = Object.keys(map).sort();
                if (rows.length === 0) { body.innerHTML = '<tr><td colspan="3" class="text-center py-4 text-muted">ไม่มีข้อมูลหมวดหมู่</td></tr>'; return; }
                rows.forEach(cat => { const r = map[cat]; const tr = document.createElement('tr'); tr.innerHTML = `<td>${cat}</td><td class="text-center">${r.count}</td><td class="text-center">${formatNumber(r.total)}</td>`; body.appendChild(tr); });
            } catch(e) { console.error(e); }
        }

        function renderActiveBorrows() {
            try {
                const body = document.querySelector('#dashActiveBorrows tbody'); if(!body) return; body.innerHTML = '';
                const borrows = allData.activeBorrows || [];
                if (borrows.length === 0) { body.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-muted">ไม่มีสินค้าที่กำลังยืม</td></tr>'; return; }
                const toolCodes = new Set((allData.tools||[]).map(t=>t.code));
                borrows.forEach(b => {
                    let item = {};
                    if (toolCodes.has(b.itemCode)) item = (allData.tools||[]).find(x=>x.code===b.itemCode) || {};
                    else item = (allData.items||[]).find(x=>x.code===b.itemCode) || {};
                    const tr = document.createElement('tr'); tr.innerHTML = `<td class="font-monospace">${b.itemCode}</td><td class="fw-bold">${b.itemName||item.name||'-'}</td><td class="text-center">${formatNumber(b.qty)}</td><td>${b.borrower||b.borrowerName||'-'}</td>`; body.appendChild(tr);
                });
            } catch(e) { console.error(e); }
        }

        function filterTxTable() {
         try {
        const startDateStr = document.getElementById('txStartDate').value;
        const endDateStr = document.getElementById('txEndDate').value;
        const searchVal = (document.getElementById('txSearch')?.value || '').trim().toLowerCase();
        const typeFilter = (document.getElementById('txTypeFilter')?.value || '').trim().toLowerCase();
        const startDt = startDateStr ? new Date(startDateStr) : null; if(startDt) startDt.setHours(0,0,0,0);
        const endDt = endDateStr ? new Date(endDateStr) : null; if(endDt) endDt.setHours(23,59,59,999);
        const filteredLogs = allData.history.filter(log => {
            const act = String(log.action).trim().toLowerCase();
            if(!['รับเข้า', 'เบิก', 'new item', 'ซ่อมแซมแล้ว', 'แจ้งชำรุด'].includes(act)) return false;
            if(typeFilter && act !== typeFilter) return false;
            if(searchVal) {
                const haystack = [log.code, log.itemName, log.user, log.remark].join(' ').toLowerCase();
                if(!haystack.includes(searchVal)) return false;
            }
            const rowDate = parseThaiDate(log.time);
            if ((startDt || endDt) && !rowDate) return false;
            if (startDt && rowDate < startDt) return false;
            if (endDt && rowDate > endDt) return false;
            return true;
        });
        renderTransactionsInOut(filteredLogs);
    } catch(e) { console.error(e); }
}

        function renderTransactionsInOut(history) {
         try {
         const tbody = document.querySelector('#txTable tbody'); 
          if(!tbody) return;
        
         // แก้จุดนี้: สั่งล้างตารางใหญ่ในหน้า "รับเข้า / เบิกออก (In/Out)" ให้หมดจดก่อนเขียนใหม่
         tbody.innerHTML = ''; 
        
         const limit = parseInt(allData.settings?.rowsPerPage) || 100; 
         const limitedFiltered = history.slice(0, limit);
         if (limitedFiltered.length === 0) { 
            tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-inbox fs-3 mb-2 d-block"></i>ไม่มีประวัติในช่วงเวลานี้</td></tr>'; 
            return; 
        }
        limitedFiltered.forEach(log => {
            const actLower = String(log.action).trim().toLowerCase(); 
            let isOut = (actLower === 'เบิก' || actLower === 'แจ้งชำรุด'); 
            let tr = document.createElement('tr'); 
            let displayAction = actLower === 'new item' ? 'รับเข้า (ใหม่)' : log.action;
            let displayUser = log.user ? String(log.user).replace(/\[.*?\]/g, '').replace(' (แจ้งชำรุด)', '').replace(' (ซ่อมแซมแล้ว)', '') : 'ไม่ระบุ';
            let badgeClass = isOut ? 'bg-danger bg-opacity-10 text-danger' : 'bg-success bg-opacity-10 text-success'; 
            let iconClass = isOut ? 'fa-arrow-down' : 'fa-arrow-up'; 
            let textClass = isOut ? 'text-danger' : 'text-success';
            let remarkText = log.remark ? String(log.remark) : '-';
            tr.innerHTML = `<td><small class="text-muted font-monospace bg-light px-2 py-1 rounded">${log.time}</small></td><td class="text-center"><span class="badge ${badgeClass} w-100 py-2"><i class="fas ${iconClass} me-1"></i> ${displayAction}</span></td><td class="fw-bold">${log.itemName} <span class="badge bg-light text-secondary border font-monospace ms-2 fw-normal">${log.code}</span></td><td class="text-end fw-bold ${textClass} fs-6">${log.amount} <span class="text-muted fw-normal small ms-1">${log.unit||''}</span></td><td class="text-center text-secondary fw-medium"><i class="fas fa-user-circle me-1"></i> ${displayUser}</td><td><small class="text-muted">${remarkText}</small></td>`;
            tbody.appendChild(tr);
        });
    } catch(e) { console.error(e); }
}

        function renderDamagedTools(damagedItems) {
            try {
                const tbody = document.querySelector('#orderToolsTable tbody'); if(!tbody) return; tbody.innerHTML = '';
                if (damagedItems.length === 0) { tbody.innerHTML = '<tr><td colspan="5" class="text-center py-5 text-success fw-bold"><i class="fas fa-check-circle fs-3 d-block mb-2"></i> เยี่ยมยอด! ไม่มีอุปกรณ์ใดรอซ่อม</td></tr>'; return; }
                damagedItems.forEach(item => {
                    let tr = document.createElement('tr'); let safeName = String(item.name || '').replace(/'/g, "\\'"); let safeCode = String(item.code || '').replace(/'/g, "\\'"); let safeUnit = String(item.unit || '').replace(/'/g, "\\'");
                    let actionBtn = currentUserProfile.role === 'admin' ? `<button class="btn btn-sm btn-success shadow-sm fw-bold w-100" onclick="openRepairModal('${safeCode}', '${safeName}', '${safeUnit}', ${item.qty})"><i class="fas fa-tools"></i> ซ่อมแล้ว</button>` : `<span class="badge bg-light text-muted border w-100 py-2">เฉพาะ Admin</span>`;
                    tr.innerHTML = `<td><span class="badge badge-code">${item.code}</span></td><td class="fw-bold text-dark">${item.name}</td><td class="text-center"><span class="badge bg-danger rounded-pill px-3 py-2 fs-6 shadow-sm">${formatNumber(item.qty)}</span></td><td class="text-muted">${item.unit}</td><td class="text-center">${actionBtn}</td>`;
                    tbody.appendChild(tr);
                });
            } catch(e) { console.error(e); }
        }

        function exportMonthlySummary() {
            Swal.fire({
                title: 'ส่งออกสรุปรายเดือน?',
                text: "ระบบจะสร้างไฟล์ Excel รวมสต็อกปัจจุบัน, ประวัติย้อนหลัง 30 วัน, รายการค้างคืน และใบสั่งซื้อค้างรับ ทั้งหมดในไฟล์เดียว",
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: 'var(--success-color)',
                cancelButtonColor: '#64748b',
                confirmButtonText: '<i class="fas fa-download"></i> ยืนยันส่งออก',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    try {
                        const wb = XLSX.utils.book_new();

                        const wsItems = XLSX.utils.json_to_sheet(allData.items.map(i => ({ 'รหัส': i.code, 'ชื่อรายการ': i.name, 'หมวดหมู่': i.category, 'ตำแหน่ง': i.location || '-', 'คงเหลือ': i.stock, 'จุดสั่งซื้อ (Min)': i.min, 'หน่วย': i.unit })));
                        XLSX.utils.book_append_sheet(wb, wsItems, "คลังอะไหล่ (Items)");

                        const wsTools = XLSX.utils.json_to_sheet(allData.tools.map(i => ({ 'รหัส': i.code, 'ชื่อเครื่องมือ': i.name, 'หมวดหมู่': i.category, 'ตำแหน่ง': i.location || '-', 'พร้อมใช้': i.stock, 'จุดสั่งซื้อ (Min)': i.min, 'หน่วย': i.unit })));
                        XLSX.utils.book_append_sheet(wb, wsTools, "เครื่องมือ (Tools)");

                        const thirtyDaysAgo = new Date();
                        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                        const recentHistory = allData.history.filter(h => {
                            const d = parseThaiDate(h.time);
                            return d ? d >= thirtyDaysAgo : false;
                        }).map(h => ({ 'วันเวลา': h.time, 'การกระทำ': h.action, 'รหัส': h.code, 'ชื่อรายการ': h.itemName, 'จำนวน': h.amount, 'คงเหลือ': h.balance, 'ผู้ดำเนินการ': h.user, 'หมายเหตุ': h.remark }));
                        const wsHistory = XLSX.utils.json_to_sheet(recentHistory.length > 0 ? recentHistory : [{'แจ้งเตือน': 'ไม่มีประวัติใน 30 วันที่ผ่านมา'}]);
                        XLSX.utils.book_append_sheet(wb, wsHistory, "ประวัติ 30 วัน (Logs)");

                        const borrows = allData.activeBorrows.map(b => ({ 'วันที่ทำรายการ': b.date, 'ผู้ยืม': b.borrower, 'รหัส': b.itemCode, 'รายการ': b.itemName, 'จำนวนยืม': b.qty, 'สถานที่นำไปใช้': b.machine, 'หมายเหตุ': b.remark }));
                        const wsBorrows = XLSX.utils.json_to_sheet(borrows.length > 0 ? borrows : [{'แจ้งเตือน': 'ไม่มีรายการค้างคืน'}]);
                        XLSX.utils.book_append_sheet(wb, wsBorrows, "ค้างส่งคืน (Borrows)");

                        const pos = allData.pendingPOs.filter(p => p.status !== 'ได้รับแล้ว').map(p => ({ 'เลขที่ PO': p.poCode, 'วันที่': p.date, 'ซัพพลายเออร์': p.supplier, 'รายการ': p.itemName, 'จำนวนค้างรับ': p.qty, 'สถานะ': p.status, 'หมายเหตุ': p.remark }));
                        const wsPOs = XLSX.utils.json_to_sheet(pos.length > 0 ? pos : [{'แจ้งเตือน': 'ไม่มีใบสั่งซื้อค้างรับ'}]);
                        XLSX.utils.book_append_sheet(wb, wsPOs, "PO ค้างรับ");

                        const fName = `Monthly_Summary_${new Date().toISOString().split('T')[0]}`;
                        XLSX.writeFile(wb, `${fName}.xlsx`);
                        
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'ส่งออกไฟล์ Excel สรุปข้อมูลเรียบร้อยแล้ว', timer: 2000, showConfirmButton: false});
                    } catch (e) {
                        Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: 'ไม่สามารถส่งออกไฟล์ได้: ' + e.message});
                    }
                }
            });
        }

        function renderMonthlyOrders(damagedItems, lowItems, pos) {
            try {
                const activePOs = pos.filter(p => p.status !== 'ได้รับแล้ว');
                const bTools = document.getElementById('badge-low-tools'); if(bTools) { bTools.innerText = damagedItems.length; bTools.style.display = damagedItems.length > 0 ? 'inline-block' : 'none'; }
                const bItems = document.getElementById('badge-low-items'); if(bItems) { bItems.innerText = lowItems.length; bItems.style.display = lowItems.length > 0 ? 'inline-block' : 'none'; }
                const bPO = document.getElementById('badge-pending-po'); if(bPO) { bPO.innerText = activePOs.length; bPO.style.display = activePOs.length > 0 ? 'inline-block' : 'none'; }

                const tItems = document.querySelector('#orderItemsTable tbody');
                if(tItems) {
                    tItems.innerHTML = '';
                    if(lowItems.length === 0) tItems.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-success fw-bold"><i class="fas fa-box fs-3 d-block mb-2"></i> สต็อกเพียงพอทุกรายการ</td></tr>';
                    else {
                        lowItems.forEach(i => { 
                            let tr = document.createElement('tr'); 
                            tr.innerHTML = `<td><span class="badge badge-code">${i.code}</span></td><td class="fw-bold text-dark">${i.name}</td><td><span class="badge bg-info bg-opacity-10 text-info px-2 py-1">${getItemCategory(i)}</span></td><td class="text-center text-danger fw-bold fs-5">${formatNumber(i.stock)}</td><td class="text-center text-primary fw-bold">${formatNumber(i.min)}</td><td class="text-muted">${i.unit}</td>`; tItems.appendChild(tr); 
                        });
                    }
                }

                const tPO = document.querySelector('#orderPOTable tbody');
                if(tPO) {
                    tPO.innerHTML = '';
                    if(activePOs.length === 0) tPO.innerHTML = '<tr><td colspan="9" class="text-center py-5 text-muted"><i class="fas fa-file-invoice fs-3 d-block mb-2"></i> ไม่มีใบสั่งซื้อค้างรับ</td></tr>';
                    else {
                        activePOs.forEach(p => { 
                            let tr = document.createElement('tr'); 
                            let fileBtn = p.fileUrl ? `<a href="${p.fileUrl}" target="_blank" class="btn btn-sm btn-outline-danger"><i class="fas fa-file-pdf"></i> PDF</a>` : '<span class="text-muted">-</span>'; 
                            let safePoCode = String(p.poCode || '').replace(/'/g, "\\'");
                            let safePOData = JSON.stringify(p).replace(/'/g, "\\'");
                            let actionBtns = currentUserProfile.role === 'admin' ? `
                                <div class="d-flex gap-1 flex-wrap">
                                    <button class="btn btn-sm btn-primary fw-bold shadow-sm" onclick="openEditPOModal('${safePoCode}')" title="แก้ไข/ติดตาม"><i class="fas fa-edit"></i> แก้ไข</button>
                                    <button class="btn btn-sm btn-success fw-bold shadow-sm" onclick="receivePO('${safePoCode}')"><i class="fas fa-check"></i> รับเข้า</button>
                                    <button class="btn btn-sm btn-danger fw-bold shadow-sm" onclick="cancelPO('${safePoCode}')" title="ยกเลิก PO"><i class="fas fa-times"></i> ยกเลิก</button>
                                </div>
                            ` : `<span class="badge bg-light text-muted border">รอของ</span>`;
                            tr.innerHTML = `<td><span class="badge bg-dark px-2 py-1">${p.poCode}</span></td><td class="text-muted small">${p.date}</td><td class="fw-bold text-dark">${p.supplier}</td><td class="fw-medium">${p.itemName}</td><td class="text-end fw-bold text-danger fs-6">${formatNumber(p.qty)}</td><td class="text-center"><span class="badge bg-warning text-dark px-2 py-1">${p.status}</span></td><td><small class="text-muted">${p.remark}</small></td><td class="text-center">${fileBtn}</td><td class="text-center" style="min-width:200px;">${actionBtns}</td>`; 
                            tPO.appendChild(tr); 
                        });
                    }
                }
            } catch(e) { console.error(e); }
        }

        function renderBorrowedTable(tableId, borrows) {
            try {
                const tbody = document.querySelector(`#${tableId} tbody`); if(!tbody) return; tbody.innerHTML = '';
                if (borrows.length === 0) { tbody.innerHTML = '<tr><td colspan="7" class="text-center py-5 text-success fw-bold"><i class="fas fa-check-circle fs-3 d-block mb-2"></i> ไม่มีรายการค้างส่งคืน</td></tr>'; return; }
                borrows.forEach(b => { 
                    let tr = document.createElement('tr'); let safeName = String(b.itemName || '').replace(/'/g, "\\'"); let safeCode = String(b.itemCode || '').replace(/'/g, "\\'"); let safeReqId = String(b.reqId || '').replace(/'/g, "\\'");
                    let actionBtn = currentUserProfile.role === 'admin' ? `<button class="btn btn-sm btn-info text-white fw-bold shadow-sm w-100" onclick="returnBorrowedItem('${safeReqId}', '${safeCode}', '${safeName}', ${b.qty})"><i class="fas fa-undo me-1"></i> กดรับคืน</button>` : `<span class="badge bg-warning text-dark px-3 py-2 w-100">รอส่งคืน</span>`;
                    tr.innerHTML = `<td><small class="text-muted font-monospace bg-light px-2 py-1 rounded">${b.date}</small></td><td class="fw-bold text-dark">${b.itemName} <span class="badge bg-light text-secondary border font-monospace ms-2 fw-normal">${b.itemCode}</span></td><td><span class="badge bg-info bg-opacity-10 text-info px-2 py-1"><i class="fas fa-map-marker-alt me-1"></i> ${b.machine}</span></td><td class="text-center fw-bold text-danger fs-5">${formatNumber(b.qty)}</td><td class="fw-medium text-secondary"><i class="fas fa-user-tag me-1"></i> ${b.borrower}</td><td><small class="text-muted">${b.remark}</small></td><td class="text-center" style="width:120px;">${actionBtn}</td>`; tbody.appendChild(tr); 
                });
            } catch(e) { console.error(e); }
        }

        function filterHistoryTable() {
            try {
                const typeFilter = document.getElementById('historyTypeFilter').value.toLowerCase().trim(); const searchText = document.getElementById('historySearch').value.toLowerCase().trim();
                const startDateStr = document.getElementById('histStartDate').value; const endDateStr = document.getElementById('histEndDate').value;
                const startDt = startDateStr ? new Date(startDateStr) : null; if(startDt) startDt.setHours(0,0,0,0); const endDt = endDateStr ? new Date(endDateStr) : null; if(endDt) endDt.setHours(23,59,59,999);
                
                const filteredLogs = allData.history.filter(log => {
                    const fullText = (String(log.code) + " " + String(log.itemName) + " " + String(log.user)).toLowerCase(); const actionText = String(log.action).toLowerCase().trim(); const rowDate = parseThaiDate(log.time);
                    if (searchText !== '' && !fullText.includes(searchText)) return false; if (typeFilter !== '' && !actionText.includes(typeFilter)) return false;
                    if ((startDt || endDt) && !rowDate) return false;
                    if (startDt && rowDate < startDt) return false; 
                    if (endDt && rowDate > endDt) return false; 
                    return true;
                });
                renderHistoryTable(filteredLogs);
            } catch(e) { console.error(e); }
        }

        function renderHistoryTable(logs) {
            try {
                const tbody = document.querySelector('#historyTable tbody'); if(!tbody) return; tbody.innerHTML = '';
                const limit = parseInt(allData.settings?.rowsPerPage) || 100; const limitedLogs = logs.slice(0, limit);
                if (limitedLogs.length === 0) { tbody.innerHTML = '<tr><td colspan="7" class="text-center py-5 text-muted"><i class="fas fa-search fs-3 d-block mb-2"></i> ไม่พบประวัติที่ตรงกับเงื่อนไขการค้นหา</td></tr>'; return; }
                
                limitedLogs.forEach(log => {
                    let tr = document.createElement('tr'); let badgeClass = 'bg-secondary'; let icon = 'fa-circle'; 
                    const actLower = String(log.action).trim().toLowerCase(); let displayAction = log.action;
                    if(actLower.includes('เบิก') || actLower.includes('ยืม') || actLower.includes('ชำรุด')) { badgeClass = 'bg-danger bg-opacity-10 text-danger'; icon = 'fa-arrow-down'; } else if(actLower.includes('รับเข้า') || actLower.includes('คืน') || actLower.includes('new item') || actLower.includes('ซ่อม')) { badgeClass = 'bg-success bg-opacity-10 text-success'; icon = 'fa-arrow-up'; if (actLower.includes('new item')) displayAction = 'รับเข้า (ใหม่)'; } else if(actLower.includes('ปรับยอด')) { badgeClass = 'bg-warning bg-opacity-10 text-warning'; icon = 'fa-sliders-h'; }
                    let displayUser = log.user ? String(log.user).replace(/\[.*?\]/g, '').replace(' (แจ้งชำรุด)', '').replace(' (ซ่อมแซมแล้ว)', '') : 'ไม่ระบุ'; let textClass = (actLower.includes('เบิก') || actLower.includes('ยืม') || actLower.includes('ชำรุด')) ? 'text-danger' : 'text-success';
                    let remarkText = log.remark ? String(log.remark) : '-';
                    tr.innerHTML = `<td><small class="text-muted font-monospace bg-light px-2 py-1 rounded">${log.time.split(' ')[1] || log.time}</small> <span class="d-block small text-muted mt-1" style="font-size:0.7em">${log.time.split(' ')[0]}</span></td><td class="text-center"><span class="badge ${badgeClass} w-100 py-2"><i class="fas ${icon} me-1"></i> ${displayAction}</span></td><td class="fw-bold text-dark">${log.itemName} <span class="badge bg-light text-secondary border font-monospace ms-2 fw-normal">${log.code}</span></td><td class="text-end fw-bold ${textClass} fs-6">${log.amount}</td><td class="text-center text-muted fw-bold">${log.balance || '-'}</td><td class="text-secondary fw-medium"><i class="fas fa-user-circle me-1"></i> ${displayUser}</td><td><small class="text-muted">${remarkText}</small></td>`;
                    tbody.appendChild(tr);
                });
            } catch(e) { console.error(e); }
        }

        // ฟังก์ชันแสดงตาราง Summary PO (สรุปตามแต่ละ PO Code - เฉพาะค้างรับ)
        function renderSummaryPOTable(pos) {
            try {
                const tbody = document.querySelector('#summaryPOTable tbody');
                if (!tbody) return;
                tbody.innerHTML = '';
                
                if (!pos || pos.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">ไม่พบ PO ตกค้าง</td></tr>';
                    return;
                }

                // กรองเฉพาะ PO ที่ยังค้างรับ (ไม่เอา "ได้รับแล้ว")
                const pendingPos = pos.filter(p => p.status !== 'ได้รับแล้ว');

                // จัดกลุ่มตามรหัส PO
                const poMap = {};
                pendingPos.forEach(p => {
                    if (!poMap[p.poCode]) {
                        poMap[p.poCode] = {
                            poCode: p.poCode,
                            date: p.date,
                            supplier: p.supplier,
                            items: [],
                            totalQty: 0,
                            status: p.status,
                            fileUrl: p.fileUrl,
                            remark: p.remark
                        };
                    }
                    poMap[p.poCode].items.push({
                        itemName: p.itemName,
                        qty: p.qty,
                        itemStatus: p.status
                    });
                    poMap[p.poCode].totalQty += Number(p.qty) || 0;
                });

                if (Object.keys(poMap).length === 0) {
                    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">🎉 ไม่มี PO ตกค้าง ทั้งหมดได้รับแล้ว!</td></tr>';
                    return;
                }

                // แสดงในตาราง
                Object.values(poMap).forEach(po => {
                    let tr = document.createElement('tr');
                    let badgeClass = 'bg-warning text-dark';
                    if (po.status === 'ได้รับแล้ว') badgeClass = 'bg-success text-white';
                    else if (po.status === 'ของขาดชั่วคราว') badgeClass = 'bg-danger text-white';
                    else if (po.status === 'กำลังผลิต') badgeClass = 'bg-info text-white';

                    let safePoCode = String(po.poCode).replace(/'/g, "\\'");
                    let actionBtns = currentUserProfile.role === 'admin' ? `
                        <div class="d-flex gap-1 flex-wrap justify-content-center">
                            <button class="btn btn-sm btn-primary fw-bold shadow-sm" onclick="openEditPOModal('${safePoCode}')" title="แก้ไข/ติดตาม"><i class="fas fa-edit"></i> แก้ไข</button>
                            <button class="btn btn-sm btn-success fw-bold shadow-sm" onclick="receivePO('${safePoCode}')" title="รับเข้าสินค้า"><i class="fas fa-check"></i> รับเข้า</button>
                            <button class="btn btn-sm btn-danger fw-bold shadow-sm" onclick="cancelPO('${safePoCode}')" title="ยกเลิก PO"><i class="fas fa-times"></i> ยกเลิก</button>
                        </div>
                    ` : `<span class="badge bg-light text-muted border">รอของ</span>`;

                    tr.innerHTML = `
                        <td><span class="badge bg-dark px-2 py-1 font-monospace">${po.poCode}</span></td>
                        <td class="text-muted small">${po.date}</td>
                        <td class="fw-bold text-dark">${po.supplier}</td>
                        <td class="text-center"><span class="badge bg-light text-dark">${po.items.length}</span></td>
                        <td class="text-end fw-bold text-danger">${formatNumber(po.totalQty)}</td>
                        <td class="text-center"><span class="badge ${badgeClass}">${po.status}</span></td>
                        <td class="text-center" style="min-width:220px;">${actionBtns}</td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch(e) { 
                console.error(e); 
            }
        }

        // ฟังก์ชันแสดงตาราง History PO (ทั้งหมด + มีตัวกรอง)
        function renderHistoryPOTableWithFilter(pos) {
            try {
                const tbody = document.querySelector('#historyPOTable tbody');
                if (!tbody) return;
                tbody.innerHTML = '';
                
                if (!pos || pos.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">ไม่พบประวัติ PO</td></tr>';
                    return;
                }

                // ใช้ตัวกรองของ poTabHistory (monthlyOrders)
                const statusFilter   = document.getElementById('poHistoryStatusFilter')?.value || 'all';
                const supplierFilter = document.getElementById('poHistorySupplierFilter')?.value || '';
                const dateFrom       = document.getElementById('poHistoryDateFrom')?.value || '';
                const dateTo         = document.getElementById('poHistoryDateTo')?.value || '';

                const filteredPos = pos.filter(p => {
                    if (statusFilter && statusFilter !== 'all' && p.status !== statusFilter) return false;
                    if (supplierFilter && !String(p.supplier + p.poCode + p.itemName).toLowerCase().includes(supplierFilter.toLowerCase())) return false;
                    if (dateFrom || dateTo) {
                        const parts = String(p.date || '').split(' ')[0].split('/');
                        if (parts.length === 3) {
                            const isEn = allData.settings?.dateFormat === 'EN';
                            const yr = isEn ? parseInt(parts[2]) + 2000 : parseInt(parts[2]) + 2500 - 543;
                            const logDate = new Date(yr, parseInt(parts[1])-1, parseInt(parts[0]));
                            if (dateFrom) { const f = new Date(dateFrom); f.setHours(0,0,0,0); if (logDate < f) return false; }
                            if (dateTo)   { const t = new Date(dateTo);   t.setHours(23,59,59,999); if (logDate > t) return false; }
                        }
                    }
                    return true;
                });

                const resultCount = document.getElementById('poHistoryResultCount');
                if (resultCount) resultCount.innerText = filteredPos.length;

                if (filteredPos.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">ไม่พบข้อมูลตามเงื่อนไขที่กรอง</td></tr>';
                    return;
                }

                const sortedPOs = [...filteredPos].reverse();
                sortedPOs.forEach(p => {
                    const tr = document.createElement('tr');
                    const fileBtn = p.fileUrl && p.fileUrl !== '#'
                        ? `<a href="${p.fileUrl}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-file-pdf"></i> PDF</a>`
                        : '-';
                    let badgeClass = 'bg-warning text-dark'; 
                    if (p.status === 'ได้รับแล้ว')         badgeClass = 'bg-success text-white'; 
                    else if (p.status === 'ของขาดชั่วคราว') badgeClass = 'bg-danger text-white';
                    else if (p.status === 'กำลังผลิต')      badgeClass = 'bg-info text-white';
                    else if (p.status === 'ยกเลิกแล้ว')     badgeClass = 'bg-secondary text-white';
                    tr.innerHTML = `
                        <td><span class="badge badge-code">${p.poCode}</span></td>
                        <td class="text-muted small">${p.date}</td>
                        <td class="fw-medium">${p.supplier}</td>
                        <td class="fw-bold">${p.itemName}</td>
                        <td class="text-end fw-bold text-primary">${formatNumber(p.qty)}</td>
                        <td class="text-center"><span class="badge ${badgeClass}">${p.status}</span></td>
                        <td><small class="text-muted">${p.remark || '-'}</small></td>
                        <td class="text-center">${fileBtn}</td>
                    `;
                    tbody.appendChild(tr);
                });
            } catch(e) { 
                console.error(e); 
            }
        }

        function filterPOHistory() {
            renderHistoryPOTableWithFilter(allData.pendingPOs);
        }

        function filterTable(tableId) {
            try {
                const isItems = (tableId === 'itemsTable');
                const searchInput = document.querySelector(`#${isItems ? 'items' : 'tools'} .search-box input`); const text = searchInput ? searchInput.value.toLowerCase().trim() : ''; 
                const categorySelect = document.getElementById(isItems ? 'itemCategoryFilter' : 'toolCategoryFilter'); const category = categorySelect ? categorySelect.value.toLowerCase().trim() : '';
                const baseData = isItems ? allData.items : allData.tools; const type = isItems ? 'item' : 'tool';
                const filteredData = baseData.filter(item => {
                    const txt = (String(item.code) + " " + String(item.name)).toLowerCase(); const catText = String(getItemCategory(item)).toLowerCase().trim();
                    if (text !== '' && !txt.includes(text)) return false; if (category !== '' && !catText.includes(category)) return false; return true;
                });
                renderTable(tableId, filteredData, type);
            } catch(e) { console.error(e); }
        }

        function renderTable(tableId, data, type) {
            try {
                const tbody = document.querySelector(`#${tableId} tbody`); if(!tbody) return; tbody.innerHTML = '';
                const limit = parseInt(allData.settings?.rowsPerPage) || 100; const limitedData = data.slice(0, limit);
                if (limitedData.length === 0) { tbody.innerHTML = '<tr><td colspan="8" class="text-center py-5 text-muted"><i class="fas fa-search fs-3 d-block mb-2"></i> ไม่พบข้อมูลที่ค้นหา</td></tr>'; return; }
                
                limitedData.forEach(item => {
                    let tr = document.createElement('tr'); const isLow = item.stock <= item.min;
                    const statusBadge = isLow ? `<span class="badge bg-danger bg-opacity-10 text-danger px-3 py-2"><i class="fas fa-exclamation-circle me-1"></i> ควรสั่งเพิ่ม</span>` : `<span class="badge bg-success bg-opacity-10 text-success px-3 py-2"><i class="fas fa-check-circle me-1"></i> สต็อกปกติ</span>`;
                    let actionButtons = ''; let safeName = String(item.name || '').replace(/'/g, "\\'"); let safeCode = String(item.code || '').replace(/'/g, "\\'"); let displayCat = getItemCategory(item); let safeCat = String(displayCat).replace(/'/g, "\\'"); let safeUnit = String(item.unit || '').replace(/'/g, "\\'"); let safeType = String(type || '').replace(/'/g, "\\'"); let safeLocation = String(item.location || '').replace(/'/g, "\\'");
                    let displayLocation = item.location ? `<span class="badge bg-light text-secondary border"><i class="fas fa-map-marker-alt text-danger me-1"></i> ${item.location}</span>` : '<small class="text-muted">-</small>';
                    
                    if (currentUserProfile.role === 'admin') {
                        let qrBtn = `<button class="btn btn-sm btn-light text-primary border me-1" onclick="showQRCode('${safeCode}', '${safeName}')" title="แสดง QR Code"><i class="fas fa-qrcode"></i></button>`;
                        let editBtn = `<button class="btn btn-sm btn-light text-warning border" onclick="openEditItemModal('${safeCode}', '${safeName}', '${safeCat}', '${safeUnit}', ${item.min}, '${safeType}', '${safeLocation}')" title="แก้ไข"><i class="fas fa-edit"></i></button>`;
                        if(type === 'item') { actionButtons = `<div class="d-flex justify-content-center gap-1">${qrBtn}${editBtn}<button class="btn btn-sm btn-light text-success border ms-1" onclick="openAdjustModal('${safeCode}', '${safeName}', '${safeUnit}', 'add')" title="เพิ่มยอดแมนนวล"><i class="fas fa-plus"></i></button><button class="btn btn-sm btn-light text-danger border" onclick="openAdjustModal('${safeCode}', '${safeName}', '${safeUnit}', 'remove')" title="ลดยอดแมนนวล"><i class="fas fa-minus"></i></button></div>`; } 
                        else if (type === 'tool') { actionButtons = `<div class="d-flex justify-content-center gap-1">${qrBtn}${editBtn}<button class="btn btn-sm btn-light text-danger border ms-1" onclick="openDamageModal('${safeCode}', '${safeName}', '${safeUnit}')" title="แจ้งเสีย"><i class="fas fa-heart-broken"></i></button><button class="btn btn-sm btn-light text-success border" onclick="openRepairModal('${safeCode}', '${safeName}', '${safeUnit}', 1)" title="ซ่อมแล้ว"><i class="fas fa-tools"></i></button></div>`; }
                    } else {
                        let qrBtn = `<button class="btn btn-sm btn-light text-primary border" onclick="showQRCode('${safeCode}', '${safeName}')" title="แสดง QR Code"><i class="fas fa-qrcode"></i></button>`;
                        if (type === 'item') { actionButtons = `<div class="d-flex justify-content-center">${qrBtn}</div>`; } else if (type === 'tool') { actionButtons = `<div class="d-flex justify-content-center gap-1">${qrBtn}<button class="btn btn-sm btn-outline-danger" onclick="openDamageModal('${safeCode}', '${safeName}', '${safeUnit}')"><i class="fas fa-heart-broken"></i> ส่งแจ้งเสีย</button></div>`; }
                    }
                    tr.innerHTML = `<td><span class="badge badge-code px-2 py-1">${item.code}</span></td><td class="fw-bold text-dark fs-6">${item.name}</td><td><span class="badge badge-cat px-2 py-1">${displayCat}</span></td><td>${displayLocation}</td><td class="text-center ${isLow?'text-danger':'text-primary'} fw-bold fs-5">${formatNumber(item.stock)}</td><td class="text-muted fw-medium">${item.unit}</td><td class="text-center">${statusBadge}</td><td class="text-center">${actionButtons}</td>`;
                    tr.style.cursor = 'pointer';
                    tr.title = 'คลิกเพื่อดูประวัติการรับเข้า';
                    tr.addEventListener('click', function(e) {
                        if (e.target.closest('button') || e.target.closest('a')) return;
                        showReceiveHistory(item.code);
                    });
                    tbody.appendChild(tr);
                });
            } catch(e) { console.error(e); }
        }

        function showReceiveHistory(itemCode) {
            const item = allData.items.find(i => i.code === itemCode) || allData.tools.find(i => i.code === itemCode);
            if (!item) return;

            document.getElementById('rhItemName').textContent = item.name;
            document.getElementById('rhItemCode').textContent = item.code;
            document.getElementById('rhItemCat').textContent = getItemCategory(item) || '-';
            document.getElementById('rhItemLoc').innerHTML = `<i class="fas fa-map-marker-alt text-danger me-1"></i> ${item.location || '-'}`;
            document.getElementById('rhItemStock').textContent = `คงเหลือ: ${formatNumber(item.stock)} ${item.unit || ''}`;

            const receiveHistory = (allData.history || []).filter(log => {
                const act = String(log.action || '').trim().toLowerCase();
                const code = String(log.code || '').trim();
                return code === itemCode && (act === 'รับเข้า' || act.includes('new item') || act.includes('รับเข้า'));
            }).sort((a, b) => {
                const da = parseThaiDate(a.time); const db = parseThaiDate(b.time);
                if (!da && !db) return 0; if (!da) return 1; if (!db) return -1;
                return db - da;
            });

            const tbody = document.getElementById('receiveHistoryTableBody');
            const noData = document.getElementById('rhNoData');
            tbody.innerHTML = '';

            document.getElementById('rhTotalCount').textContent = receiveHistory.length + ' ครั้ง';

            if (receiveHistory.length === 0) {
                tbody.innerHTML = '';
                noData.classList.remove('d-none');
            } else {
                noData.classList.add('d-none');
                receiveHistory.forEach(log => {
                    const tr = document.createElement('tr');
                    const timeParts = (log.time || '').split(' ');
                    const dateStr = timeParts[0] || '-';
                    const timeStr = timeParts[1] || '';
                    const displayUser = String(log.user || 'ไม่ระบุ').replace(/\[.*?\]/g, '').trim();
                    const amountRaw = String(log.amount || '0').replace(/[^0-9.]/g, '');
                    const amountNum = parseFloat(amountRaw) || 0;
                    tr.innerHTML = `
                        <td>
                            <span class="fw-bold text-dark d-block small">${dateStr}</span>
                            <span class="text-muted" style="font-size:0.8em">${timeStr}</span>
                        </td>
                        <td class="text-center fw-bold text-success fs-6">+${formatNumber(amountNum)}</td>
                        <td class="text-center text-primary fw-bold">${log.balance || '-'}</td>
                        <td><i class="fas fa-user-circle me-1 text-muted"></i> <span class="fw-medium">${displayUser}</span></td>
                        <td><small class="text-muted">${log.remark || '-'}</small></td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            const modal = new bootstrap.Modal(document.getElementById('receiveHistoryModal'));
            modal.show();
        }

        function filterUsersTable() {
            try {
                const filter = document.getElementById('userSearch').value.toLowerCase().trim();
                const filteredUsers = allData.users.filter(u => String(u.name).toLowerCase().includes(filter));
                renderUsersTable(filteredUsers);
            } catch(e) { console.error(e); }
        }

        function renderUsersTable(users) {
            try {
                const tbody = document.querySelector('#usersTable tbody'); tbody.innerHTML = '';
                if (!users || users.length === 0) { tbody.innerHTML = '<tr><td colspan="4" class="text-center py-4 text-muted">ไม่พบข้อมูล</td></tr>'; return; }
                let pendingCount = 0;
                users.forEach(u => {
                    let tr = document.createElement('tr'); let badgeHtml = ''; let actionHtml = ''; let safeUid = String(u.userId || '').replace(/'/g, "\\'");
                    if (u.role === 'admin') { badgeHtml = '<span class="badge bg-primary px-3 py-2 shadow-sm"><i class="fas fa-crown me-1"></i> Admin</span>'; actionHtml = `<button class="btn btn-sm btn-outline-secondary rounded-pill px-3" onclick="updateUserRole('${safeUid}', 'user')"><i class="fas fa-arrow-down"></i> ปรับเป็น User</button>`; } 
                    else if (u.role === 'user') { badgeHtml = '<span class="badge bg-success bg-opacity-10 text-success px-3 py-2"><i class="fas fa-user-check me-1"></i> User</span>'; actionHtml = `<div class="btn-group shadow-sm"><button class="btn btn-sm btn-light text-danger border" onclick="updateUserRole('${safeUid}', 'rejected')" title="ระงับสิทธิ์"><i class="fas fa-ban"></i></button><button class="btn btn-sm btn-light text-primary border" onclick="updateUserRole('${safeUid}', 'admin')" title="อัปเกรดเป็น Admin"><i class="fas fa-crown"></i></button></div>`; } 
                    else if (u.role === 'pending') { pendingCount++; badgeHtml = '<span class="badge bg-warning text-dark px-3 py-2 shadow-sm">รออนุมัติ</span>'; actionHtml = `<div class="btn-group shadow-sm"><button class="btn btn-sm btn-success fw-bold" onclick="updateUserRole('${safeUid}', 'user')"><i class="fas fa-check"></i> อนุมัติ</button><button class="btn btn-sm btn-danger fw-bold" onclick="updateUserRole('${safeUid}', 'rejected')"><i class="fas fa-times"></i> ปฏิเสธ</button></div>`; tr.classList.add('table-warning'); } 
                    else { badgeHtml = '<span class="badge bg-danger px-3 py-2">ถูกระงับสิทธิ์</span>'; actionHtml = `<button class="btn btn-sm btn-outline-success rounded-pill px-3" onclick="updateUserRole('${safeUid}', 'user')">ปลดแบน</button>`; tr.classList.add('text-muted'); }
                    tr.innerHTML = `<td><small class="font-monospace text-secondary bg-light px-2 py-1 rounded">${u.userId.substring(0,10)}...</small></td><td class="fw-bold text-dark">${u.name}</td><td class="text-center">${badgeHtml}</td><td class="text-center">${actionHtml}</td>`;
                    tbody.appendChild(tr);
                });
                const badge = document.getElementById('pendingUserCount'); if(badge) { badge.innerText = pendingCount; badge.style.display = pendingCount > 0 ? 'inline-block' : 'none'; }
            } catch(e) { console.error(e); }
        }

        function openTxModal(type) {
            document.getElementById('txForm').reset(); document.getElementById('txType').value = type;
            const header = document.getElementById('txModalHeader'); const title = document.getElementById('txModalTitle'); const btn = document.getElementById('txSubmitBtn');
            if(type === 'รับเข้า') { header.className = 'modal-header bg-success text-white border-0'; title.innerHTML = '<i class="fas fa-arrow-up me-2"></i> รับเข้าคลัง (Check-in)'; btn.className = 'btn btn-success fw-bold shadow-md px-5 py-2 fs-6'; btn.innerText = 'บันทึกยอดรับเข้า'; } 
            else { header.className = 'modal-header bg-danger text-white border-0'; title.innerHTML = '<i class="fas fa-arrow-down me-2"></i> เบิกออกไปใช้งาน (Check-out)'; btn.className = 'btn btn-danger fw-bold shadow-md px-5 py-2 fs-6'; btn.innerText = 'ยืนยันการเบิกออก'; }
            const txUserEl = document.getElementById('txUser'); txUserEl.value = currentUserProfile.name; txUserEl.readOnly = true; txUserEl.classList.add('bg-light');
            const txDateEl = document.getElementById('txDate'); txDateEl.value = new Date().toISOString().slice(0, 10);
            const catSelect = document.getElementById('txCategory'); catSelect.innerHTML = '<option value="">-- ไม่กรอง (แสดงทั้งหมด) --</option>';
            const uniqueCats = getCombinedCategories(allData.items.concat(allData.tools));
            uniqueCats.forEach(cat => { let opt = document.createElement('option'); opt.value = cat; opt.text = cat; catSelect.appendChild(opt); });
            catSelect.value = ''; updateTxItemOptions(); txModal.show();
        }

        function updateTxItemOptions() {
            const type = document.getElementById('txType').value; const selectedCat = document.getElementById('txCategory').value;
            const select = document.getElementById('txItemCode'); 
            try { if(window.txSelectInstance) { window.txSelectInstance.destroy(); window.txSelectInstance = null; } } catch(e) {}
            select.innerHTML = '<option value="">🔍 ค้นหาด้วย ชื่อรายการ หรือ SKU...</option>';
            let groups = [{ group: '📦 คลังอะไหล่', items: allData.items }, { group: '🛠️ เครื่องมือ', items: allData.tools }];
            groups.forEach(g => {
                let filteredItems = g.items; if (selectedCat) filteredItems = filteredItems.filter(i => getItemCategory(i) === selectedCat);
                if(filteredItems.length > 0) {
                    let optGroup = document.createElement('optgroup'); optGroup.label = g.group;
                    filteredItems.forEach(i => { 
                        let opt = document.createElement('option'); opt.value = i.code; 
                        let locText = i.location ? ` | พิกัด: ${i.location}` : ''; let stockText = `Stock: ${formatNumber(i.stock)}`;
                        if (type === 'เบิก' && i.stock <= 0) { opt.disabled = true; stockText = 'ของหมดแล้ว!'; } 
                        opt.text = `[${i.code}] ${i.name} (${stockText}${locText})`; optGroup.appendChild(opt); 
                    }); select.appendChild(optGroup);
                }
            });
            window.txSelectInstance = new TomSelect("#txItemCode", { create: false, sortField: { field: "text", direction: "asc" } });
        }

        function submitTransaction() {
    const submitBtn = document.getElementById('txSubmitBtn');
    if (submitBtn.disabled) return; 

    // ดึงค่าหมายเหตุจากช่องกรอก txRemark บนหน้าเว็บส่งไปด้วย
    const payload = { 
        mode: document.getElementById('txType').value, 
        code: document.getElementById('txItemCode').value, 
        qty: parseFloat(document.getElementById('txQty').value), 
        date: document.getElementById('txDate').value,
        user: document.getElementById('txUser').value.trim(), 
        userId: currentUserProfile.uid,
        remark: document.getElementById('txRemark').value.trim() // 🆕 ดึงค่าหมายเหตุส่งไปหลังบ้าน
    };

    if(!payload.code || !payload.qty || !payload.user) return Swal.fire({icon: 'warning', title: 'ข้อมูลไม่ครบ', text: 'กรุณาระบุข้อมูลที่จำเป็น (*) ให้ครบ'});
    if(!Number.isInteger(payload.qty) || payload.qty < 1) return Swal.fire({icon: 'warning', title: 'จำนวนไม่ถูกต้อง', text: 'กรุณาระบุจำนวนเป็นจำนวนเต็มอย่างน้อย 1'});
    if(allData.settings?.reqRemark && !payload.remark) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'นโยบายระบบบังคับให้ระบุหมายเหตุ/สถานที่นำไปใช้เสมอ'});

    let item = allData.items.find(i=>i.code===payload.code) || allData.tools.find(i=>i.code===payload.code);
    if(!item) return Swal.fire({icon: 'error', title: 'ไม่พบรายการ', text: 'ไม่พบรายการสินค้านี้ในระบบ'});
    
    submitBtn.disabled = true;
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> กำลังบันทึก...';

    document.getElementById('loading').style.display = 'flex'; 
    txModal.hide();

    if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run.withSuccessHandler(function(res) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            document.getElementById('loading').style.display = 'none';

            if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
            else {
                writeAudit('TRANSACTION', `${payload.mode} — [${payload.code}] จำนวน ${payload.qty} | หมายเหตุ: ${payload.remark || '-'}`);
                Swal.fire({icon: 'success', title: 'เสร็จสิ้น!', text: `ดำเนินการ${payload.mode}เสร็จสิ้น!`, timer: 1500, showConfirmButton: false});
                loadData(true); 
            }
        }).withFailureHandler(function(err) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            document.getElementById('loading').style.display = 'none';
            writeAudit('TRANSACTION', `${payload.mode} — [${payload.code}] ล้มเหลว: ${err.message}`, 'FAIL');
            Swal.fire({icon: 'error', title: 'เกิดข้อผิดพลาด', text: err.message});
        }).webTransaction(payload);
    } else { 
        setTimeout(() => { 
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            document.getElementById('loading').style.display = 'none';
            writeAudit('TRANSACTION', `${payload.mode} — [${payload.code}] จำนวน ${payload.qty} (Demo)`);
            Swal.fire({icon: 'success', title: 'เสร็จสิ้น!', text: `จำลองทำรายการ${payload.mode}เสร็จสิ้น!`, timer: 1500, showConfirmButton: false});
            loadData(true);
        }, 500); 
    }
}


        function openAddBorrowModal(borrowType) {
            borrowType = borrowType || 'Tools';
            document.getElementById('addBorrowForm').reset();
            document.getElementById('borrowDate').valueAsDate = new Date();
            document.getElementById('addBorrowModal').dataset.type = borrowType;

            // อัปเดต title และ header color ตาม type
            const modalTitle = document.getElementById('addBorrowModalTitle');
            const modalHeader = modalTitle ? modalTitle.closest('.modal-header') : null;
            if (borrowType === 'Items') {
                if (modalTitle) modalTitle.innerHTML = '<i class="fas fa-box-open me-2"></i> แบบฟอร์มขอยืมอะไหล่';
                if (modalHeader) { modalHeader.classList.remove('bg-primary'); modalHeader.classList.add('bg-info'); }
            } else {
                if (modalTitle) modalTitle.innerHTML = '<i class="fas fa-toolbox me-2"></i> แบบฟอร์มขอยืมเครื่องมือ/อุปกรณ์';
                if (modalHeader) { modalHeader.classList.remove('bg-info'); modalHeader.classList.add('bg-primary'); }
            }

            updateBorrowItemOptions(borrowType);
            addBorrowModal.show();
        }


        function updateBorrowItemOptions(borrowType) {
            borrowType = borrowType || document.getElementById('addBorrowModal').dataset.type || 'Tools';
            const isItems = (borrowType === 'Items');

            const select = document.getElementById('borrowItemCode');
            try { if(window.borrowSelectInstance) { window.borrowSelectInstance.destroy(); window.borrowSelectInstance = null; } } catch(e) {}

            const placeholder = isItems
                ? '🔍 พิมพ์ค้นหาชื่อหรือรหัสอะไหล่...'
                : '🔍 พิมพ์ค้นหาชื่อหรือรหัสเครื่องมือ...';
            select.innerHTML = `<option value="">${placeholder}</option>`;

            const list = isItems ? (allData.items || []) : (allData.tools || []);

            if (list.length > 0) {
                // จัดกลุ่มตาม category
                const grouped = {};
                list.forEach(i => {
                    const cat = (i.category || 'ไม่ระบุหมวดหมู่').trim();
                    if (!grouped[cat]) grouped[cat] = [];
                    grouped[cat].push(i);
                });

                // สร้าง optgroup แยกตาม category
                Object.keys(grouped).sort().forEach(cat => {
                    let optGroup = document.createElement('optgroup');
                    optGroup.label = (isItems ? '📦 ' : '🛠️ ') + cat;
                    grouped[cat].forEach(i => {
                        let opt = document.createElement('option');
                        opt.value = i.code;
                        let locText = i.location ? ` | วาง: ${i.location}` : '';
                        let stockText = i.stock > 0 ? `ว่าง: ${formatNumber(i.stock)} ${i.unit||''}` : 'ถูกยืมหมดแล้ว';
                        if (i.stock <= 0) opt.disabled = true;
                        opt.text = `[${i.code}] ${i.name} (${stockText}${locText})`;
                        optGroup.appendChild(opt);
                    });
                    select.appendChild(optGroup);
                });
            }
            window.borrowSelectInstance = new TomSelect("#borrowItemCode", { create: false, sortField: { field: "text", direction: "asc" } });
        }

        function submitAddBorrow() {
            const payload = { 
                code: document.getElementById('borrowItemCode').value, 
                qty: parseFloat(document.getElementById('borrowQty').value), 
                borrower: document.getElementById('borrowerName').value.trim(), 
                machine: document.getElementById('borrowMachine').value.trim(), 
                date: document.getElementById('borrowDate').value, 
                remark: document.getElementById('borrowRemark').value.trim(),
                user: currentUserProfile.name,
                userId: currentUserProfile.uid
            };
            if(!payload.code || !payload.qty || !payload.borrower || !payload.machine) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'โปรดกรอกข้อมูลสำคัญให้ครบ'});
            if(!Number.isInteger(payload.qty) || payload.qty < 1) return Swal.fire({icon: 'warning', title: 'จำนวนไม่ถูกต้อง', text: 'กรุณาระบุจำนวนเป็นจำนวนเต็มอย่างน้อย 1'});
            if(allData.settings?.reqRemark && !payload.remark) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ต้องระบุหมายเหตุการยืมด้วยครับ'});
            let item = allData.tools.find(i=>i.code===payload.code) || allData.items.find(i=>i.code===payload.code);
            if(!item) return Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: 'ข้อมูลไม่ถูกต้อง โปรดเลือกจาก Dropdown ใหม่'});
            
            document.getElementById('loading').style.display = 'flex'; addBorrowModal.hide();
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                    else {
                        writeAudit('BORROW', `ยืม [${payload.code}] จำนวน ${payload.qty} | ผู้ยืม: ${payload.borrower} | สถานที่: ${payload.machine}`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: allData.settings?.autoApprove ? 'ดำเนินการเสร็จสิ้น! คุณยืมได้ทันที' : 'ส่งใบคำขอยืมเข้าระบบแล้ว (กรุณารอผู้ดูแลยืนยัน)', timer: 2500, showConfirmButton: false}); 
                        if(allData.settings?.autoApprove && item) item.stock -= payload.qty;
                        onDataLoaded(allData);
                    }
                }).webAddBorrow(payload);
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('BORROW', `ยืม [${payload.code}] จำนวน ${payload.qty} | ผู้ยืม: ${payload.borrower} (Demo)`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองการยืมสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
        }

        function returnBorrowedItem(reqId, itemCode, itemName, qty) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            
            Swal.fire({
                title: 'ยืนยันการรับคืน',
                text: `ยืนยันว่าได้รับคืนสินค้า: ${itemName} (จำนวน ${qty}) สภาพสมบูรณ์ใช่หรือไม่? (ระบบจะคืนยอดสต็อกอัตโนมัติ)`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: 'var(--success-color)',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'ยืนยันรับคืน',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run) {
                        google.script.run.withSuccessHandler(function(res) {
                            if(!res.success) { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); } 
                            else { writeAudit('BORROW', `รับคืน [${itemCode}] ${itemName} จำนวน ${qty}`); loadData(false); setTimeout(() => Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกรับคืนสำเร็จ! ยอดอัปเดตกลับเข้าคลังเรียบร้อย', timer: 2000, showConfirmButton: false}), 500); }
                        }).webReturnItem(reqId, currentUserProfile.name, currentUserProfile.uid);
                    } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'รับคืนสำเร็จ! ยอดอัปเดตกลับเข้าคลังเรียบร้อย', timer: 2000, showConfirmButton: false}); }, 500); }
                }
            });
        }

        function openAddPOModal() { 
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            document.getElementById('addPOForm').reset(); 
            document.getElementById('poDate').valueAsDate = new Date();
            document.getElementById('poItemsBody').innerHTML = '';
            addPOItemRow(); // เพิ่มแถวแรกให้อัตโนมัติ
            addPOModal.show(); 
        }
        
        function addPOItemRow() {
            const tbody = document.getElementById('poItemsBody');
            const rowCount = tbody.children.length;
            const rowId = 'poItem_' + Date.now() + '_' + rowCount;
            
            const newRow = document.createElement('tr');
            newRow.id = rowId;
            newRow.innerHTML = `
                <td class="ps-3">
                    <input type="text" class="form-control form-control-sm shadow-sm poItemName" placeholder="ระบุรายละเอียดสินค้า" required>
                </td>
                <td class="text-center">
                    <input type="number" class="form-control form-control-sm text-center fw-bold shadow-sm poItemQty" min="0.01" step="any" placeholder="0" required>
                </td>
                <td>
                    <select class="form-select form-select-sm shadow-sm poItemStatus">
                        <option value="รอจัดส่ง">รอจัดส่ง</option>
                        <option value="กำลังผลิต">กำลังผลิต</option>
                        <option value="ของขาดชั่วคราว">ของขาดชั่วคราว</option>
                    </select>
                </td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-danger" onclick="removePOItemRow('${rowId}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(newRow);
        }
        
        function removePOItemRow(rowId) {
            document.getElementById(rowId).remove();
        }

        function savePO() {
            const poCode = document.getElementById('poCode').value.trim();
            const poDate = document.getElementById('poDate').value;
            const poSupplier = document.getElementById('poSupplier').value.trim();
            const poRemark = document.getElementById('poRemark').value.trim();
            
            if (!poCode || !poDate || !poSupplier) {
                return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรอกข้อมูล PO, วันที่, และซัพพลายเออร์ให้ครบถ้วน'});
            }
            
            // รวบรวมรายการสินค้า
            const poItems = [];
            const itemRows = document.querySelectorAll('#poItemsBody tr');
            
            if (itemRows.length === 0) {
                return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเพิ่มรายการสินค้าอย่างน้อย 1 รายการ'});
            }
            
            for (let row of itemRows) {
                const itemName = row.querySelector('.poItemName').value.trim();
                const itemQty = row.querySelector('.poItemQty').value;
                const itemStatus = row.querySelector('.poItemStatus').value;
                
                if (!itemName || !itemQty) {
                    return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ทุกรายการต้องมีชื่อและจำนวนค้างรับ'});
                }
                
                poItems.push({
                    itemName: itemName,
                    qty: itemQty,
                    status: itemStatus
                });
            }
            
            // คำนวณจำนวนรวม
            const totalQty = poItems.reduce((sum, item) => sum + parseFloat(item.qty || 0), 0);
            
            const poData = { 
                poCode: poCode,
                date: poDate,
                supplier: poSupplier,
                items: poItems,
                totalQty: totalQty,
                remark: poRemark,
                user: currentUserProfile.name,
                userId: currentUserProfile.uid
            };
            
            const file = document.getElementById('poPdfFile').files[0];
            if (file) {
                if (file.size > 5 * 1024 * 1024) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ขนาดไฟล์ PDF ห้ามเกิน 5MB'});
                const reader = new FileReader(); 
                reader.onload = function(e) { 
                    poData.pdfBase64 = e.target.result.split(',')[1]; 
                    poData.pdfName = file.name; 
                    sendPOData(poData); 
                }; 
                reader.readAsDataURL(file);
            } else {
                sendPOData(poData);
            }
        }

        function sendPOData(poData) {
            document.getElementById('loading').style.display = 'flex'; 
            addPOModal.hide();
            
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if (!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                    else { 
                        writeAudit('PO', `เปิด PO ใหม่ [${poData.poCode}] Supplier: ${poData.supplier} | ${poData.items.length} รายการ`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกเปิด PO สำเร็จ! (' + poData.items.length + ' รายการ)', timer: 2000, showConfirmButton: false});
                        
                        let d = new Date(poData.date); 
                        let fDate = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getFullYear()+543).slice(-2)}`;
                        
                        // สร้างรายการสำหรับแต่ละสินค้า
                        poData.items.forEach(item => {
                            allData.pendingPOs.push({ 
                                poCode: poData.poCode, 
                                date: fDate, 
                                supplier: poData.supplier, 
                                itemCode: '-', 
                                itemName: item.itemName, 
                                qty: item.qty, 
                                status: item.status, 
                                remark: poData.remark, 
                                fileUrl: poData.fileUrl || "" 
                            });
                        });
                        
                        onDataLoaded(allData);
                        resetPOForm();
                    }
                }).webAddPendingPO(poData);
            } else { 
                setTimeout(() => { 
                    document.getElementById('loading').style.display = 'none'; 
                    writeAudit('PO', `เปิด PO ใหม่ [${poData.poCode}] Supplier: ${poData.supplier} | ${poData.items.length} รายการ (Demo)`);
                    Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองเปิด PO สำเร็จ (' + poData.items.length + ' รายการ)', timer: 2000, showConfirmButton: false}); 
                    
                    // เพิ่มข้อมูลลง allData สำหรับ Simulation mode
                    let d = new Date(poData.date); 
                    let fDate = `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getFullYear()+543).slice(-2)}`;
                    
                    poData.items.forEach(item => {
                        allData.pendingPOs.push({ 
                            poCode: poData.poCode, 
                            date: fDate, 
                            supplier: poData.supplier, 
                            itemCode: '-', 
                            itemName: item.itemName, 
                            qty: item.qty, 
                            status: item.status, 
                            remark: poData.remark, 
                            fileUrl: poData.fileUrl || ""
                        });
                    });
                    
                    onDataLoaded(allData);
                    resetPOForm();
                }, 500); 
            }
        }
        
        function resetPOForm() {
            document.getElementById('addPOForm').reset();
            document.getElementById('poItemsBody').innerHTML = '';
        }
        
        // ฟังก์ชันแก้ไข/ติดตาม PO
        function openEditPOModal(poCode) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            
            // ค้นหา PO ทั้งหมดที่มีรหัส PO เดียวกัน
            const poItems = allData.pendingPOs.filter(p => p.poCode === poCode);
            
            if (poItems.length === 0) {
                return Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: 'ไม่พบ PO ที่ต้องการ'});
            }
            
            const firstItem = poItems[0];
            
            // กรอกข้อมูลพื้นฐาน
            document.getElementById('editPoCode').value = poCode;
            document.getElementById('editPoDate').value = firstItem.date;
            document.getElementById('editPoSupplier').value = firstItem.supplier;
            document.getElementById('editPoRemark').value = firstItem.remark || '';
            document.getElementById('editPoStatus').value = firstItem.status || 'รอจัดส่ง';
            
            // แสดงรายการสินค้า
            const tbody = document.getElementById('editPoItemsBody');
            tbody.innerHTML = '';
            
            poItems.forEach((item, index) => {
                const rowId = 'editPoItem_' + index;
                const row = document.createElement('tr');
                row.id = rowId;
                row.innerHTML = `
                    <td class="ps-3">
                        <input type="text" class="form-control form-control-sm shadow-sm editPoItemName" value="${item.itemName}" placeholder="ชื่อรายการ">
                    </td>
                    <td class="text-center">
                        <input type="number" class="form-control form-control-sm text-center fw-bold shadow-sm editPoItemQty" value="${item.qty}" min="0.01" step="any">
                    </td>
                    <td>
                        <select class="form-select form-select-sm shadow-sm editPoItemStatus">
                            <option value="รอจัดส่ง" ${item.status === 'รอจัดส่ง' ? 'selected' : ''}>รอจัดส่ง</option>
                            <option value="กำลังผลิต" ${item.status === 'กำลังผลิต' ? 'selected' : ''}>กำลังผลิต</option>
                            <option value="ของขาดชั่วคราว" ${item.status === 'ของขาดชั่วคราว' ? 'selected' : ''}>ของขาดชั่วคราว</option>
                            <option value="ได้รับแล้ว" ${item.status === 'ได้รับแล้ว' ? 'selected' : ''}>ได้รับแล้ว</option>
                        </select>
                    </td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-danger" onclick="removeEditPOItemRow('${rowId}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            editPOModal.show();
        }
        
        function removeEditPOItemRow(rowId) {
            document.getElementById(rowId).remove();
        }
        
        function saveEditPO() {
            const poCode = document.getElementById('editPoCode').value.trim();
            const poSupplier = document.getElementById('editPoSupplier').value.trim();
            const poRemark = document.getElementById('editPoRemark').value.trim();
            const poStatus = document.getElementById('editPoStatus').value;
            
            if (!poCode || !poSupplier) {
                return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณากรอกข้อมูลให้ครบถ้วน'});
            }
            
            // รวบรวมรายการสินค้าที่แก้ไข
            const updatedItems = [];
            const itemRows = document.querySelectorAll('#editPoItemsBody tr');
            
            if (itemRows.length === 0) {
                return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเพิ่มรายการสินค้าอย่างน้อย 1 รายการ'});
            }
            
            for (let row of itemRows) {
                const itemName = row.querySelector('.editPoItemName').value.trim();
                const itemQty = row.querySelector('.editPoItemQty').value;
                const itemStatus = row.querySelector('.editPoItemStatus').value;
                
                if (!itemName || !itemQty) {
                    return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ทุกรายการต้องมีชื่อและจำนวนค้างรับ'});
                }
                
                updatedItems.push({
                    itemName: itemName,
                    qty: parseFloat(itemQty),
                    status: itemStatus
                });
            }
            
            // เตรียมข้อมูลส่งไปยัง Backend
            const poData = {
                poCode: poCode,
                date: document.getElementById('editPoDate').value,
                supplier: poSupplier,
                items: updatedItems,
                remark: poRemark,
                fileUrl: ''
            };
            
            // แสดง loading
            document.getElementById('loading').style.display = 'flex';
            editPOModal.hide();
            
            // เรียก Backend
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if (!res.success) {
                        Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                    } else {
                        writeAudit('PO', `แก้ไข PO [${poCode}] Supplier: ${poSupplier} | ${updatedItems.length} รายการ`);
                        Swal.fire({
                            icon: 'success',
                            title: 'สำเร็จ!',
                            text: 'บันทึกการแก้ไข PO สำเร็จ! (' + updatedItems.length + ' รายการ)',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        
                        // อัปเดต allData เพื่ออัปเดตตารางทันที
                        allData.pendingPOs = allData.pendingPOs.filter(p => p.poCode !== poCode);
                        updatedItems.forEach(item => {
                            allData.pendingPOs.push({
                                poCode: poCode,
                                date: poData.date,
                                supplier: poSupplier,
                                itemCode: '-',
                                itemName: item.itemName,
                                qty: item.qty,
                                status: item.status,
                                remark: poRemark,
                                fileUrl: ''
                            });
                        });
                        
                        onDataLoaded(allData);
                        
                        // ✅ อัปเดตตาราง Summary และ History
                        renderSummaryPOTable(allData.pendingPOs);
                        renderHistoryPOTableWithFilter(allData.pendingPOs);
                    }
                }).webUpdatePendingPO(poData);
            } else {
                // Simulation mode
                setTimeout(() => {
                    document.getElementById('loading').style.display = 'none';
                    Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองแก้ไข PO สำเร็จ (' + updatedItems.length + ' รายการ)', timer: 2000, showConfirmButton: false});
                    
                    // อัปเดต allData
                    allData.pendingPOs = allData.pendingPOs.filter(p => p.poCode !== poCode);
                    updatedItems.forEach(item => {
                        allData.pendingPOs.push({
                            poCode: poCode,
                            date: poData.date,
                            supplier: poSupplier,
                            itemCode: '-',
                            itemName: item.itemName,
                            qty: item.qty,
                            status: item.status,
                            remark: poRemark,
                            fileUrl: ''
                        });
                    });
                    
                    onDataLoaded(allData);
                    
                    // ✅ อัปเดตตาราง Summary และ History
                    renderSummaryPOTable(allData.pendingPOs);
                    renderHistoryPOTableWithFilter(allData.pendingPOs);
                }, 500);
            }
        }

        function receivePO(poCode) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            Swal.fire({
                title: 'ยืนยันรับสินค้า', text: `ยืนยันว่าได้รับสินค้าสำหรับ PO: ${poCode} แล้วใช่หรือไม่? (ระบบจะเปลี่ยนสถานะเป็น "ได้รับแล้ว")`, icon: 'question', showCancelButton: true, confirmButtonColor: 'var(--success-color)', cancelButtonColor: '#64748b', confirmButtonText: 'ยืนยันรับสินค้า', cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run) {
                        google.script.run.withSuccessHandler(function(res) {
                            document.getElementById('loading').style.display = 'none';
                            if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                            else {
                                writeAudit('PO', `รับสินค้า PO [${poCode}] เรียบร้อย — สถานะเปลี่ยนเป็น "ได้รับแล้ว"`);
                                Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'อัปเดตสถานะ PO สำเร็จ! กรุณาทำรายการ "รับเข้า" ที่หน้าจัดการสต็อกด้วยตนเองเพื่อเพิ่มยอด'});
                                allData.pendingPOs.forEach(p => { if (p.poCode === poCode) p.status = 'ได้รับแล้ว'; });
                                onDataLoaded(allData);
                                renderSummaryPOTable(allData.pendingPOs);
                                renderHistoryPOTableWithFilter(allData.pendingPOs);
                            }
                        }).webReceivePO(poCode, currentUserProfile.name, currentUserProfile.uid);
                    } else { 
                        setTimeout(() => { 
                            document.getElementById('loading').style.display = 'none'; 
                            allData.pendingPOs.forEach(p => { if (p.poCode === poCode) p.status = 'ได้รับแล้ว'; });
                            Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองรับ PO สำเร็จ'}); 
                            onDataLoaded(allData);
                            renderSummaryPOTable(allData.pendingPOs);
                            renderHistoryPOTableWithFilter(allData.pendingPOs);
                        }, 500); 
                    }
                }
            });
        }

        function cancelPO(poCode) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});

            Swal.fire({
                title: `ยกเลิก PO: ${poCode}?`,
                html: `
                    <p class="text-muted mb-3">กรุณาระบุสาเหตุการยกเลิก</p>
                    <textarea id="cancelPOReason" class="form-control" rows="3" placeholder="เช่น ซัพพลายเออร์ไม่สามารถจัดส่งได้, ยกเลิกคำสั่งซื้อ, เปลี่ยน Supplier ใหม่..."></textarea>
                `,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: '<i class="fas fa-times-circle me-1"></i> ยืนยันยกเลิก PO',
                cancelButtonText: 'ไม่ยกเลิก',
                didOpen: () => { document.getElementById('cancelPOReason').focus(); },
                preConfirm: () => {
                    const reason = document.getElementById('cancelPOReason').value.trim();
                    if (!reason) {
                        Swal.showValidationMessage('กรุณาระบุสาเหตุการยกเลิก');
                        return false;
                    }
                    return reason;
                }
            }).then((result) => {
                if (!result.isConfirmed) return;
                const reason = result.value;

                document.getElementById('loading').style.display = 'flex';
                if (typeof google !== 'undefined' && google.script && google.script.run) {
                    google.script.run
                        .withSuccessHandler(function(res) {
                            document.getElementById('loading').style.display = 'none';
                            if (!res.success) return Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error});
                            writeAudit('PO', `ยกเลิก PO [${poCode}] — สาเหตุ: ${reason}`);
                            Swal.fire({icon: 'success', title: 'ยกเลิก PO แล้ว', text: `PO ${poCode} ถูกยกเลิกเรียบร้อย`, timer: 2000, showConfirmButton: false});
                            // ลบออกจาก cache แล้ว re-render
                            allData.pendingPOs = allData.pendingPOs.filter(p => p.poCode !== poCode);
                            onDataLoaded(allData);
                            renderSummaryPOTable(allData.pendingPOs);
                            renderHistoryPOTableWithFilter(allData.pendingPOs);
                        })
                        .withFailureHandler(function(err) {
                            document.getElementById('loading').style.display = 'none';
                            Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: String(err)});
                        })
                        .webCancelPO(poCode, reason, currentUserProfile.name, currentUserProfile.uid);
                } else {
                    setTimeout(() => {
                        document.getElementById('loading').style.display = 'none';
                        writeAudit('PO', `ยกเลิก PO [${poCode}] — สาเหตุ: ${reason} (Demo)`);
                        allData.pendingPOs = allData.pendingPOs.filter(p => p.poCode !== poCode);
                        Swal.fire({icon: 'success', title: 'ยกเลิก PO แล้ว (Demo)', timer: 2000, showConfirmButton: false});
                        onDataLoaded(allData);
                        renderSummaryPOTable(allData.pendingPOs);
                        renderHistoryPOTableWithFilter(allData.pendingPOs);
                    }, 500);
                }
            });
        }

        function getNextCodeForWeb(type, category, extraUsedCodes = []) {
    const s = allData.settings || {};
    const defaultPrefix = (type === 'Tools') ? (s.prefixTool || 'TL') : (s.prefixItem || 'IT');

    // Step 1: หา prefix จาก settings category mapping ก่อน (format: "ชื่อหมวด:PREFIX")
    let prefix = null;
    if (s.categories && category) {
        const parts = s.categories.split(',');
        for (let p of parts) {
            const str = p.trim();
            if (str.includes(':')) {
                const colonIdx = str.indexOf(':');
                const catName = str.substring(0, colonIdx).trim();
                const catPrefix = str.substring(colonIdx + 1).trim();
                if (catName.toLowerCase() === category.trim().toLowerCase() && catPrefix !== '') {
                    prefix = catPrefix.toUpperCase();
                    break;
                }
            }
        }
    }

    // Step 2: ถ้าไม่มี mapping ใน settings → เดาจาก codes ที่มีอยู่จริงในหมวดนั้น
    if (!prefix && category) {
        const allList = (allData.items || []).concat(allData.tools || []);
        const itemsInCat = allList.filter(i =>
            getItemCategory(i).trim().toLowerCase() === category.trim().toLowerCase()
        );

        if (itemsInCat.length > 0) {
            // นับความถี่ของ prefix แต่ละตัว (เอาเฉพาะส่วนก่อน "-" แรก)
            const prefixCount = {};
            itemsInCat.forEach(item => {
                const codeStr = String(item.code || '').toUpperCase().trim();
                // ตัด suffix ตัวเลขออก เหลือแค่ prefix เช่น "BL-001" → "BL"
                const match = codeStr.match(/^([A-Z]+(?:-[A-Z]+)*)-\d+$/);
                if (match) {
                    const p = match[1]; // เช่น "BL", "HDL", "PM"
                    prefixCount[p] = (prefixCount[p] || 0) + 1;
                }
            });

            // เอา prefix ที่ใช้บ่อยที่สุดในหมวดนี้
            if (Object.keys(prefixCount).length > 0) {
                prefix = Object.keys(prefixCount).sort((a, b) => prefixCount[b] - prefixCount[a])[0];
            }
        }
    }

    // Step 3: ถ้ายังไม่มีเลย ใช้ default
    if (!prefix) prefix = defaultPrefix;

    // Step 4: สร้าง candidatePrefix เช่น "BL-", "HDL-", "IT-"
    const candidatePrefix = prefix.replace(/-+$/, '') + '-';

    // Step 5: รวม codes ทั้งหมด (DB + แถวในฟอร์ม) แล้วหาเลขสูงสุด
    const allList = (allData.items || []).concat(allData.tools || []);
    const checkCodes = allList.map(i => String(i.code || '').toUpperCase())
        .concat((extraUsedCodes || []).map(c => String(c).toUpperCase()));

    let maxNum = 0;
    let maxLen = 3;
    checkCodes.forEach(codeStr => {
        if (!codeStr.startsWith(candidatePrefix)) return;
        const suffix = codeStr.slice(candidatePrefix.length);
        if (!/^\d+$/.test(suffix)) return; // ต้องเป็นตัวเลขล้วนๆ
        const num = parseInt(suffix, 10);
        if (!isNaN(num)) {
            maxNum = Math.max(maxNum, num);
            maxLen = Math.max(maxLen, suffix.length);
        }
    });

    const nextNum = maxNum + 1;
    return `${candidatePrefix}${String(nextNum).padStart(maxLen, '0')}`;
}

        function updateNewItemCode() {
            const ts = document.getElementById('newItemType');
            const ci = document.getElementById('newItemCat');
            const cdi = document.getElementById('newItemCode');
            if (!ts || !ci || !cdi) return;
            const category = String(ci.value || '').trim();
            cdi.value = getNextCodeForWeb(ts.value, category);
        }

        function populateCategoryDatalist(elementId, typeString) {
            try {
                const datalist = document.getElementById(elementId); if (!datalist) return; datalist.innerHTML = '';
                const type = String(typeString || '').trim().toLowerCase();
                let list = [];
                if (type === 'tools' || type === 'tool') list = allData.tools;
                else if (type === 'items' || type === 'item') list = allData.items;
                else list = allData.items.concat(allData.tools);
                let uniqueCats = getCombinedCategories(list);
                uniqueCats.forEach(cat => { let opt = document.createElement('option'); opt.value = cat; datalist.appendChild(opt); });
            } catch(e) { console.error(e); }
        }

        function openNewItemModal(forcedType) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            document.getElementById('newItemForm').reset();
            
            const ts = document.getElementById('newItemType');
            const ci = document.getElementById('newItemCat');
            const locDatalist = document.getElementById('locationOptions');
            if (locDatalist) { locDatalist.innerHTML = ''; const uniqueLocs = getCombinedLocations(allData.items.concat(allData.tools)); uniqueLocs.forEach(loc => { let opt = document.createElement('option'); opt.value = loc; locDatalist.appendChild(opt); }); }
            
            const userField = document.getElementById('newItemUser');
            if (userField) userField.value = currentUserProfile.name;
            const dateField = document.getElementById('newItemDate');
            if (dateField) dateField.value = new Date().toISOString().slice(0, 10);
            
            if(forcedType) ts.value = forcedType;
            populateCategoryDatalist('categoryOptions', ts.value);
            ts.onchange = function() { populateCategoryDatalist('categoryOptions', this.value); ci.value = ''; };
            
            const tbody = document.getElementById('newItemsTableBody');
            tbody.innerHTML = '';
            window.newItemRowCounter = 0;
            addNewItemRow();
            
            newItemModal.show();
        }

        function addNewItemRow() {
    const tbody = document.getElementById('newItemsTableBody');
    window.newItemRowCounter = (window.newItemRowCounter || 0) + 1;
    const rowId = 'row_' + window.newItemRowCounter + '_' + Math.random().toString(36).substr(2, 9);
    
    // 1. ดึงประเภทและหมวดหมู่ปัจจุบันมาเตรียมใช้
    const type = document.getElementById('newItemType').value;
    const category = document.getElementById('newItemCat').value.trim();
    
    // 2. ดึงรหัสสินค้าที่มีอยู่แล้วทั้งหมดบนจอ
    const currentCodesInModal = [];
    document.querySelectorAll('#newItemsTableBody [data-code-input]').forEach(input => {
        if (input.value.trim() !== '') {
            currentCodesInModal.push(input.value.trim().toUpperCase());
        }
    });
    
    // 3. เจนรหัสถัดไปที่แท้จริง (ไม่ซ้ำกับแถวอื่นบนจอ)
    const nextGeneratedCode = getNextCodeForWeb(type, category, currentCodesInModal);

    const row = document.createElement('tr');
    row.id = rowId;
    row.innerHTML = `
        <td>
            <div class="input-group input-group-sm">
                <!-- นำรหัสที่ได้ใส่ในช่อง value ทันที -->
                <input type="text" class="form-control shadow-sm fw-bold text-primary" data-code-input value="${nextGeneratedCode}" placeholder="AUTO" readonly style="cursor: pointer;">
                <button type="button" class="btn btn-outline-primary btn-sm fw-bold" onclick="autoGenerateCodeForRow('${rowId}')"><i class="fas fa-magic me-1"></i>Auto</button>
            </div>
        </td>
        <td>
            <input type="text" class="form-control form-control-sm shadow-sm fw-bold" data-name-input placeholder="ชื่อรายการ" required>
        </td>
        <td>
            <input type="text" class="form-control form-control-sm shadow-sm" data-location-input list="locationOptions" placeholder="ตำแหน่ง">
        </td>
        <td>
            <input type="text" class="form-control form-control-sm shadow-sm text-center" data-unit-input placeholder="หน่วย" required>
        </td>
        <td>
            <input type="number" class="form-control form-control-sm shadow-sm text-center" data-min-input min="0" step="any" value="0">
        </td>
        <td>
            <input type="number" class="form-control form-control-sm shadow-sm text-center fw-bold text-success" data-qty-input min="0" step="any" placeholder="จำนวน" required>
        </td>
        <td class="text-center">
            <button type="button" class="btn btn-sm btn-danger" onclick="removeNewItemRow('${rowId}')"><i class="fas fa-trash"></i></button>
        </td>
    `;
    tbody.appendChild(row);
}

       function autoGenerateCodeForRow(rowId) {
    const row = document.getElementById(rowId);
    if (!row) return;
    const type = document.getElementById('newItemType').value;
    const category = document.getElementById('newItemCat').value.trim();
    if (!type || !category) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'เลือกประเภทและหมวดหมู่ก่อน'});
    
    // ดึงรหัสที่ใช้อยู่ในแถวอื่นๆ ทั้งหมดบนจอขณะนั้น มารวมคำนวณด้วย
    const currentCodesInModal = [];
    document.querySelectorAll('#newItemsTableBody tr').forEach(r => {
        if (r.id !== rowId) {
            const inp = r.querySelector('[data-code-input]');
            if (inp && inp.value.trim() !== '') {
                currentCodesInModal.push(inp.value.trim().toUpperCase());
            }
        }
    });

    const code = getNextCodeForWeb(type, category, currentCodesInModal);
    row.querySelector('[data-code-input]').value = code;
}


        function removeNewItemRow(rowId) {
            const row = document.getElementById(rowId);
            if (row) row.remove();
        }

        function submitNewItems() {
            const type = document.getElementById('newItemType').value;
            const category = document.getElementById('newItemCat').value.trim();
            const date = document.getElementById('newItemDate').value;
            const user = document.getElementById('newItemUser').value.trim() || currentUserProfile.name;
            const globalRemark = document.getElementById('newItemGlobalRemark').value.trim();
            
            if (!type || !category) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเลือกประเภทและหมวดหมู่'});
            
            const tbody = document.getElementById('newItemsTableBody');
            const rows = tbody.querySelectorAll('tr');
            if (rows.length === 0) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเพิ่มรายการอย่างน้อย 1 รายการ'});
            
            let payloads = [];
            rows.forEach((row, idx) => {
                const code = row.querySelector('[data-code-input]').value.trim();
                const name = row.querySelector('[data-name-input]').value.trim();
                const location = row.querySelector('[data-location-input]').value.trim();
                const unit = row.querySelector('[data-unit-input]').value.trim();
                const min = parseFloat(row.querySelector('[data-min-input]').value) || 0;
                const qty = parseFloat(row.querySelector('[data-qty-input]').value) || 0;
                
                if (!code || !name || !unit) {
                    Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: `แถว ${idx + 1}: กรุณากรอกรหัส ชื่อ และหน่วย`});
                    return;
                }
                
                payloads.push({
                    type: type,
                    category: category,
                    code: code,
                    name: name,
                    location: location,
                    unit: unit,
                    min: min,
                    qty: qty,
                    date: date,
                    remark: globalRemark,
                    user: user,
                    userId: currentUserProfile.uid
                });
            });
            
            if (payloads.length === 0) return;
            
            document.getElementById('loading').style.display = 'flex';
            newItemModal.hide();
            
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if (!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error});
                    else {
                        writeAudit('NEW_ITEM', `ขึ้นทะเบียนใหม่ ${payloads.length} รายการ — ประเภท: ${type} | หมวด: ${category} | รหัส: ${payloads.map(p=>p.code).join(', ')}`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: `เพิ่มรายการใหม่ ${payloads.length} รายการสำเร็จ!`, timer: 2000, showConfirmButton: false});
                        
                        const itemList = type === 'Tools' ? allData.tools : allData.items;
                        payloads.forEach(p => {
                            itemList.push({ code: p.code, name: p.name, category: p.category, location: p.location, unit: p.unit, min: p.min, stock: p.qty, date: p.date, remark: p.remark });
                            allData.history.unshift({ time: getFormattedDate(), action: 'รับเข้า', code: p.code, itemName: p.name, amount: '+' + formatNumber(p.qty), balance: formatNumber(p.qty), user: p.user });
                        });
                        onDataLoaded(allData);
                    }
                }).webAddNewItems(payloads);
            } else {
                setTimeout(() => {
                    document.getElementById('loading').style.display = 'none';
                    writeAudit('NEW_ITEM', `ขึ้นทะเบียนใหม่ ${payloads.length} รายการ — ประเภท: ${type} | หมวด: ${category} (Demo)`);
                    Swal.fire({icon: 'success', title: 'สำเร็จ!', text: `จำลองเพิ่มรายการใหม่ ${payloads.length} รายการสำเร็จ`, timer: 2000, showConfirmButton: false});
                    
                    const itemList = type === 'Tools' ? allData.tools : allData.items;
                    payloads.forEach(p => {
                        itemList.push({ code: p.code, name: p.name, category: p.category, location: p.location, unit: p.unit, min: p.min, stock: p.qty, date: p.date, remark: p.remark });
                        allData.history.unshift({ time: getFormattedDate(), action: 'รับเข้า', code: p.code, itemName: p.name, amount: '+' + formatNumber(p.qty), balance: formatNumber(p.qty), user: p.user });
                    });
                    onDataLoaded(allData);
                }, 500);
            }
        }


        function openEditItemModal(code, name, category, unit, min, type, location) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            const ci = document.getElementById('editItemCat'); const cdi = document.getElementById('editItemCode'); const ti = document.getElementById('editItemType');
            cdi.value = code; document.getElementById('editItemName').value = name; ci.value = category; document.getElementById('editItemUnit').value = unit; document.getElementById('editItemMin').value = min; ti.value = type; document.getElementById('editItemLocation').value = location;
            populateCategoryDatalist('editCategoryOptions', type); const locDatalist = document.getElementById('editLocationOptions');
            if (locDatalist) { locDatalist.innerHTML = ''; const uniqueLocs = getCombinedLocations(allData.items.concat(allData.tools)); uniqueLocs.forEach(loc => { let opt = document.createElement('option'); opt.value = loc; locDatalist.appendChild(opt); }); }
            ci.onfocus = function() { if (this.value === '') { let val = this.value; this.value = ' '; this.value = val; } }; editItemModal.show();
        }

        function submitEditItem() {
            const payload = { code: document.getElementById('editItemCode').value, name: document.getElementById('editItemName').value.trim(), category: document.getElementById('editItemCat').value.trim(), location: document.getElementById('editItemLocation').value.trim(), unit: document.getElementById('editItemUnit').value.trim(), min: parseFloat(document.getElementById('editItemMin').value) || 0, type: document.getElementById('editItemType').value, user: currentUserProfile.name, userId: currentUserProfile.uid };
            if(!payload.name || !payload.category || !payload.unit) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณากรอกข้อมูลที่มี * ให้ครบถ้วน'});
            document.getElementById('loading').style.display = 'flex'; editItemModal.hide();
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                if(google.script.run.webEditItem) {
                    google.script.run.withSuccessHandler(function(res) {
                        document.getElementById('loading').style.display = 'none';
                        if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                        else {
                            writeAudit('EDIT_ITEM', `แก้ไข [${payload.code}] ชื่อ: ${payload.name} | หมวด: ${payload.category} | Min: ${payload.min}`);
                            Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'อัปเดตข้อมูลสินค้าเสร็จสมบูรณ์!', timer: 2000, showConfirmButton: false});
                            let targetList = payload.type === 'tool' ? allData.tools : allData.items; let item = targetList.find(i => i.code === payload.code);
                            if(item) { item.name = payload.name; item.category = payload.category; item.location = payload.location; item.unit = payload.unit; item.min = payload.min; } onDataLoaded(allData);
                        }
                    }).webEditItem(payload);
                } else setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('EDIT_ITEM', `แก้ไข [${payload.code}] (Demo)`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองอัปเดตข้อมูลสินค้าเสร็จสมบูรณ์!', timer: 2000, showConfirmButton: false}); }, 500);
            } else setTimeout(() => { document.getElementById('loading').style.display = 'none'; }, 500);
        }

        function openAdjustModal(code, name, unit, type) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            document.getElementById('modalItemCode').innerText = code; document.getElementById('modalItemName').innerText = name; document.getElementById('modalUnit').innerText = unit; document.getElementById('adjustItemCode').value = code; document.getElementById('adjustQty').value = ''; setAdjustType(type); adjustModal.show();
        }

        function setAdjustType(type) {
            document.getElementById('adjustType').value = type; const display = document.getElementById('adjustTypeDisplay'); const btnAdd = document.querySelector('#adjustForm .btn-outline-success'); const btnRem = document.querySelector('#adjustForm .btn-outline-danger');
            if(type === 'add') { display.innerHTML = '<span class="text-success"><i class="fas fa-plus-circle"></i> เพิ่มยอด</span>'; btnAdd.classList.add('active'); btnRem.classList.remove('active'); } else { display.innerHTML = '<span class="text-danger"><i class="fas fa-minus-circle"></i> ลดยอด</span>'; btnRem.classList.add('active'); btnAdd.classList.remove('active'); }
        }

        function confirmAdjust() {
            const code = document.getElementById('adjustItemCode').value; const qty = parseFloat(document.getElementById('adjustQty').value); const type = document.getElementById('adjustType').value;
            if(!qty || qty <= 0) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ระบุจำนวนให้ถูกต้อง'});
            const adjustQty = type === 'add' ? qty : -qty;
            document.getElementById('loading').style.display = 'flex'; adjustModal.hide();
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(result) {
                    document.getElementById('loading').style.display = 'none';
                    if (result && !result.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: result.error}); 
                    else { 
                        writeAudit('ADJUST', `ปรับยอด [${code}] ${adjustQty > 0 ? '+' : ''}${adjustQty} (${type === 'add' ? 'เพิ่ม' : 'ลด'})`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกสำเร็จ!', timer: 2000, showConfirmButton: false});
                        let item = allData.items.find(i=>i.code===code) || allData.tools.find(i=>i.code===code); if(item) item.stock += adjustQty;
                        allData.history.unshift({ time: getFormattedDate(), action: 'ปรับยอด', code: code, itemName: item ? item.name : '', amount: (adjustQty > 0 ? '+' : '') + formatNumber(Math.abs(adjustQty)), balance: item ? formatNumber(item.stock) : '-', user: currentUserProfile.name });
                        onDataLoaded(allData);
                    }
                }).webAdjustStock(code, adjustQty, currentUserProfile.name, currentUserProfile.uid);
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('ADJUST', `ปรับยอด [${code}] ${adjustQty > 0 ? '+' : ''}${adjustQty} (Demo)`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองปรับยอดสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
        }

        function openDamageModal(code, name, unit) {
            document.getElementById('damageItemCode').innerText = code; document.getElementById('damageItemCodeHidden').value = code; document.getElementById('damageItemName').innerText = name; document.getElementById('damageUnit').innerText = unit; document.getElementById('damageQty').value = '1'; document.getElementById('damageRemark').value = ''; 
            const dmgUser = document.getElementById('damageUser'); dmgUser.value = currentUserProfile.name; dmgUser.readOnly = true; dmgUser.classList.add('bg-light'); damageModal.show();
        }

        function submitDamage() {
            const code = document.getElementById('damageItemCodeHidden').value; const qty = parseFloat(document.getElementById('damageQty').value); const user = document.getElementById('damageUser').value.trim(); const remark = document.getElementById('damageRemark').value.trim();
            if(!qty || !user || !remark) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณากรอกฟอร์มให้ครบถ้วน'});
            const payload = { mode: 'แจ้งชำรุด', code: code, qty: qty, user: user + ' [ชำรุด: '+ remark +']', userId: currentUserProfile.uid, remark: 'ชำรุด: ' + remark };
            document.getElementById('loading').style.display = 'flex'; damageModal.hide();
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                    else { 
                        writeAudit('DAMAGE', `แจ้งชำรุด [${code}] จำนวน ${qty} | สาเหตุ: ${remark}`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'ส่งบันทึกแจ้งชำรุดสำเร็จ!', timer: 2000, showConfirmButton: false});
                        let item = allData.tools.find(i=>i.code===code) || allData.items.find(i=>i.code===code); if(item) item.stock -= qty;
                        allData.history.unshift({ time: getFormattedDate(), action: 'แจ้งชำรุด', code: code, itemName: item ? item.name : '', amount: '-' + formatNumber(qty), balance: item ? formatNumber(item.stock) : '-', user: payload.user, remark: payload.remark });
                        onDataLoaded(allData);
                    }
                }).webTransaction(payload);
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('DAMAGE', `แจ้งชำรุด [${code}] จำนวน ${qty} (Demo)`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองแจ้งชำรุดสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
        }

        function openRepairModal(code, name, unit, defaultQty = 1) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon:'error', title:'ปฏิเสธการเข้าถึง', text:'เฉพาะ Admin เท่านั้นที่บันทึกซ่อมเสร็จได้'});
            document.getElementById('repairItemCode').innerText = code; document.getElementById('repairItemCodeHidden').value = code; document.getElementById('repairItemName').innerText = name; document.getElementById('repairUnit').innerText = unit; document.getElementById('repairQty').value = defaultQty; document.getElementById('repairRemark').value = ''; 
            const repUser = document.getElementById('repairUser'); repUser.value = currentUserProfile.name; repUser.readOnly = true; repUser.classList.add('bg-light'); repairModal.show();
        }

        function submitRepair() {
            const code = document.getElementById('repairItemCodeHidden').value; const qty = parseFloat(document.getElementById('repairQty').value); const user = document.getElementById('repairUser').value.trim(); const remark = document.getElementById('repairRemark').value.trim();
            if(!qty || !user || !remark) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณากรอกฟอร์มให้ครบถ้วน'});
            const payload = { mode: 'ซ่อมแซมแล้ว', code: code, qty: qty, user: user + ' (ซ่อมแซมแล้ว)', userId: currentUserProfile.uid, remark: 'ซ่อมแซม: ' + remark };
            document.getElementById('loading').style.display = 'flex'; repairModal.hide();
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                    else { 
                        writeAudit('DAMAGE', `ซ่อมแซมแล้ว [${code}] จำนวน ${qty} | รายละเอียด: ${remark}`);
                        Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'บันทึกว่าซ่อมเสร็จแล้ว! จำนวนสต็อกถูกเพิ่มกลับ', timer: 2000, showConfirmButton: false});
                        let item = allData.tools.find(i=>i.code===code) || allData.items.find(i=>i.code===code); if(item) item.stock += qty;
                        allData.history.unshift({ time: getFormattedDate(), action: 'ซ่อมแซมแล้ว', code: code, itemName: item ? item.name : '', amount: '+' + formatNumber(qty), balance: item ? formatNumber(item.stock) : '-', user: payload.user, remark: payload.remark });
                        onDataLoaded(allData);
                    }
                }).webTransaction(payload);
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; writeAudit('DAMAGE', `ซ่อมแซมแล้ว [${code}] จำนวน ${qty} (Demo)`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองซ่อมเสร็จสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
        }

        function updateUserRole(userId, newRole) {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            let roleName = newRole === 'admin' ? "Admin" : newRole === 'user' ? "User ปกติ" : "ระงับสิทธิ์";
            Swal.fire({
                title: 'ยืนยันการเปลี่ยนสิทธิ์', text: `ยืนยันการปรับเปลี่ยนสิทธิ์เป็น "${roleName}" หรือไม่?`, icon: 'warning', showCancelButton: true, confirmButtonColor: 'var(--primary-color)', cancelButtonColor: '#64748b', confirmButtonText: 'ยืนยัน', cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run) {
                        google.script.run.withSuccessHandler(function(res) {
                            document.getElementById('loading').style.display = 'none';
                            if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                            else { writeAudit('USER_MGMT', `เปลี่ยนสิทธิ์ผู้ใช้ [${userId}] เป็น: ${newRole}`); Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'เปลี่ยนสิทธิ์สำเร็จ!', timer: 2000, showConfirmButton: false}); let u = allData.users.find(u => u.userId === userId); if(u) u.role = newRole; onDataLoaded(allData); }
                        }).webUpdateUser({userId: userId, role: newRole, actionBy: currentUserProfile.name});
                    } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองปรับสิทธิ์สำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
                }
            });
        }

        function downloadBackup() {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            document.getElementById('loading').style.display = 'flex';
            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run.withSuccessHandler(function(res) {
                    document.getElementById('loading').style.display = 'none';
                    if(!res.success) return Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error});
                    const backupData = JSON.parse(res.data); const wb = XLSX.utils.book_new();
                    for(const sheetName in backupData) XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(backupData[sheetName]), sheetName);
                    XLSX.writeFile(wb, `Mountain_Inventory_Backup_${new Date().toISOString().split('T')[0]}.xlsx`);
                }).webGetBackupData();
            } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองดาวน์โหลดสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
        }

        function confirmClearLogs() {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            Swal.fire({
                title: 'ล้างประวัติ Logs?', text: "ประวัติเก่าจะหายไปทั้งหมด แนะนำให้ดาวน์โหลด Backup ก่อน! ต้องการดำเนินการหรือไม่?", icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444', cancelButtonColor: '#64748b', confirmButtonText: 'ล้างข้อมูล', cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run) {
                        google.script.run.withSuccessHandler(function(res) {
                            document.getElementById('loading').style.display = 'none';
                            if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                            else { Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'ล้างประวัติLogs เรียบร้อย!', timer: 2000, showConfirmButton: false}); allData.history = []; onDataLoaded(allData); }
                        }).webClearLogs(currentUserProfile.name);
                    } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'จำลองล้างล็อกสำเร็จ', timer: 2000, showConfirmButton: false}); }, 500); }
                }
            });
        }

        function confirmFactoryReset() {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon: 'error', title: 'ปฏิเสธการเข้าถึง', text: 'สิทธิ์การใช้งานไม่เพียงพอ! (เฉพาะ Admin เท่านั้น)'});
            Swal.fire({
                title: 'Factory Reset', text: "พิมพ์คำว่า 'RESET' เพื่อยืนยันการล้างฐานข้อมูลทั้งหมดทิ้ง (ไม่สามารถย้อนกลับได้)", input: 'text', icon: 'warning', showCancelButton: true, confirmButtonColor: '#ef4444', cancelButtonColor: '#64748b', confirmButtonText: 'ล้างระบบ', cancelButtonText: 'ยกเลิก',
                inputValidator: (value) => { if (value !== 'RESET') { return 'กรุณาพิมพ์ RESET ให้ถูกต้อง' } }
            }).then((result) => {
                if (result.isConfirmed && result.value === 'RESET') {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run && google.script.run.webFactoryReset) {
                        google.script.run.withSuccessHandler(function(res) {
                            document.getElementById('loading').style.display = 'none';
                            if(!res.success) Swal.fire({icon: 'error', title: 'ข้อผิดพลาด', text: res.error}); 
                            else { Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'ล้างฐานข้อมูลสำเร็จ ระบบจะเริ่มใหม่หมด!', timer: 2000, showConfirmButton: false}).then(() => location.reload()); }
                        }).webFactoryReset(currentUserProfile.name);
                    } else { setTimeout(() => { document.getElementById('loading').style.display = 'none'; Swal.fire({icon: 'success', title: 'สำเร็จ!', text: 'ล้างฐานข้อมูลสำเร็จ ระบบจะเริ่มใหม่หมด!', timer: 2000, showConfirmButton: false}); }, 500); }
                }
            });
        }

        function showQRCode(itemCode, itemName) {
            const modal = document.getElementById('qrViewModal');
            if (!modal) return;
            document.getElementById('qrItemName').innerText = itemName;
            document.getElementById('qrItemCode').innerText = itemCode;
            const qrContainer = document.getElementById('qrCodeDisplay');
            qrContainer.innerHTML = '';
            new QRCode(qrContainer, { text: itemCode, width: 200, height: 200, colorDark: "#1e293b", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.H });
            const qrViewModal = bootstrap.Modal.getOrCreateInstance(modal);
            qrViewModal.show();
        }

        function filterQRTable() {
            const typeFilter = document.getElementById('qrTypeFilter').value;
            const catFilter = document.getElementById('qrCategoryFilter').value.toLowerCase().trim();
            const search = document.getElementById('qrSearchInput').value.toLowerCase().trim();
            
            let list = [];
            if(typeFilter === 'all' || typeFilter === 'items') { allData.items.forEach(i => list.push({...i, itemType: 'Items (อะไหล่)'})); }
            if(typeFilter === 'all' || typeFilter === 'tools') { allData.tools.forEach(t => list.push({...t, itemType: 'Tools (เครื่องมือ)'})); }

            const filtered = list.filter(item => {
                const itemCat = getItemCategory(item).toLowerCase().trim();
                const text = `${item.code} ${item.name} ${itemCat}`.toLowerCase();
                let match = true;
                if(search !== '' && !text.includes(search)) match = false;
                if(catFilter !== '' && itemCat !== catFilter) match = false;
                return match;
            });

            renderQRTable(filtered);
        }

        function renderQRTable(data) {
            const tbody = document.querySelector('#qrManageTable tbody'); tbody.innerHTML = '';
            if(data.length === 0) { 
                tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">ไม่พบข้อมูล</td></tr>'; 
                document.getElementById('qrSelectAll').checked = false;
                updateSelectedQRCount();
                return; 
            }

            let allChecked = true;
            let countRendered = 0;

            data.forEach(item => {
                const tr = document.createElement('tr'); const cat = getItemCategory(item);
                const safeName = String(item.name).replace(/'/g, "\\'"); const safeCode = String(item.code).replace(/'/g, "\\'");
                const isChecked = selectedQRCodes.has(item.code);
                if (!isChecked) allChecked = false;
                countRendered++;

                tr.innerHTML = `
                    <td class="text-center"><input class="form-check-input qr-checkbox" type="checkbox" value="${item.code}" data-name="${safeName}" onchange="toggleSingleQR(this)" ${isChecked ? 'checked' : ''}></td>
                    <td><span class="badge badge-code">${item.code}</span></td>
                    <td class="fw-bold">${item.name}</td>
                    <td><span class="badge badge-cat px-2 py-1">${cat}</span></td>
                    <td><small class="text-muted">${item.itemType}</small></td>
                    <td class="text-center"><button class="btn btn-sm btn-outline-primary rounded-circle" onclick="showQRCode('${safeCode}', '${safeName}')" title="ดู QR"><i class="fas fa-qrcode"></i></button></td>
                `;
                tbody.appendChild(tr);
            });

            document.getElementById('qrSelectAll').checked = (countRendered > 0 && allChecked);
            updateSelectedQRCount();
        }

        function toggleSingleQR(cb) {
            if (cb.checked) { selectedQRCodes.add(cb.value); } else { selectedQRCodes.delete(cb.value); }
            updateSelectedQRCount();
            const checkboxes = document.querySelectorAll('.qr-checkbox');
            const allChecked = Array.from(checkboxes).every(c => c.checked);
            document.getElementById('qrSelectAll').checked = (checkboxes.length > 0 && allChecked);
        }

        function toggleSelectAllQR(cb) {
            const checkboxes = document.querySelectorAll('.qr-checkbox');
            checkboxes.forEach(c => {
                c.checked = cb.checked;
                if (cb.checked) { selectedQRCodes.add(c.value); } else { selectedQRCodes.delete(c.value); }
            });
            updateSelectedQRCount();
        }

        function updateSelectedQRCount() {
            document.getElementById('qrSelectedCount').innerText = selectedQRCodes.size;
        }

        function printBulkQRCodes() {
            if(selectedQRCodes.size === 0) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'กรุณาเลือกรายการที่ต้องการพิมพ์อย่างน้อย 1 รายการ'});

            const allList = allData.items.concat(allData.tools);
            const itemsToPrint = Array.from(selectedQRCodes).map(code => { 
                const found = allList.find(i => i.code === code);
                return { code: code, name: found ? found.name : code }; 
            });

            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Print Bulk QR Codes</title>
                    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@400;600;700&display=swap" rel="stylesheet">
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"><\/script>
                    <style>
                        body { font-family: 'Prompt', sans-serif; margin: 0; padding: 15px; background: white; }
                        .grid-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px; }
                        .label-card { border: 2px dashed #94a3b8; border-radius: 12px; padding: 15px; text-align: center; page-break-inside: avoid; display: flex; flex-direction: column; align-items: center; justify-content: center; }
                        .qr-placeholder { margin-bottom: 10px; }
                        .item-name { font-size: 14px; font-weight: 700; color: #1e293b; margin: 0 0 5px 0; line-height: 1.2; word-wrap: break-word; max-width: 100%; }
                        .item-code { font-size: 12px; font-family: monospace; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; border: 1px solid #cbd5e1; margin: 0; font-weight: bold; }
                        @media print { body { padding: 0; } .label-card { border: 1px solid #000; } }
                    </style>
                </head>
                <body>
                    <div class="grid-container" id="grid"></div>
                    <script>
                        const items = ${JSON.stringify(itemsToPrint)};
                        const grid = document.getElementById('grid');
                        items.forEach((item, index) => {
                            const card = document.createElement('div'); card.className = 'label-card';
                            card.innerHTML = \`<div id="qr-\${index}" class="qr-placeholder"></div><h3 class="item-name">\${item.name}</h3><p class="item-code">\${item.code}</p>\`;
                            grid.appendChild(card);
                        });
                        window.onload = function() {
                            setTimeout(() => {
                                items.forEach((item, index) => { new QRCode(document.getElementById('qr-' + index), { text: item.code, width: 120, height: 120, colorDark: "#000000", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.M }); });
                                setTimeout(() => { window.print(); }, 800);
                            }, 300);
                        };
                    <\/script>
                </body>
                </html>
            `);
            printWindow.document.close();
            
            // บันทึกประวัติการพิมพ์ QR Code แบบกลุ่ม
            const printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
            itemsToPrint.forEach(item => {
                const historyRecord = {
                    id: Date.now() + Math.random(),
                    itemName: item.name,
                    itemCode: item.code,
                    printedAt: new Date().toLocaleString('th-TH'),
                    timestamp: Date.now(),
                    type: 'QR Code'
                };
                printHistory.unshift(historyRecord);
            });
            localStorage.setItem('qrBarcodeHistory', JSON.stringify(printHistory));
            
            // อัปเดตตารางประวัติ
            updateHistoryTable();
            updateHistoryStats();
        }

        function printAppScannerQR() {
            // ลิงก์ล่าสุดที่คุณให้มา
            const appUrl = "https://script.google.com/macros/s/AKfycbwcffBl6OQpgQmxVd6Auq8Q7-HXT_OXInZ5gWHWBwT-xypC4kPw_uJoGMhyrPbMX01ttg/exec?page=scanner";
            
            // เปิดหน้าต่างใหม่ขึ้นมารอไว้ก่อนเลย ป้องกัน Pop-up Blocker
            const printWindow = window.open('', '_blank');
            
            // สร้าง QR Code ซ่อนไว้ในหน้าจอหลัก
            const tempDiv = document.createElement('div');
            new QRCode(tempDiv, { 
                text: appUrl, 
                width: 300, 
                height: 300, 
                colorDark: "#000000", 
                colorLight: "#ffffff", 
                correctLevel: QRCode.CorrectLevel.H 
            });

            // รอ 0.15 วินาทีให้รูปแปลงเสร็จ แล้วเขียนลงหน้าต่างใหม่
            setTimeout(() => {
                const canvas = tempDiv.querySelector('canvas');
                const imgData = canvas ? canvas.toDataURL("image/png") : "";
                
                printWindow.document.write(`
                    <html>
                    <head>
                        <title>QR Code สำหรับเข้าหน้าสแกน</title>
                        <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@400;600;700&display=swap" rel="stylesheet">
                        <style>
                            body { font-family: 'Prompt', sans-serif; text-align: center; padding: 40px; background: #f8fafc; }
                            .label-card { border: 2px dashed #4f46e5; padding: 40px; display: inline-block; border-radius: 16px; background: #fff; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); }
                            .item-name { font-size: 28px; font-weight: 700; color: #1e293b; margin: 20px 0 10px 0; }
                            .item-desc { font-size: 18px; color: #64748b; margin-bottom: 30px; }
                            #qr-app { display: flex; justify-content: center; }
                        </style>
                    </head>
                    <body>
                        <div class="label-card">
                            <h3 class="item-name">จุดบริการสแกนสินค้า</h3>
                            <p class="item-desc">สแกน QR นี้เพื่อเข้าสู่ระบบทำรายการ (เบิก/รับเข้า/ยืม)</p>
                            <div id="qr-app"><img src="${imgData}" style="width: 300px; height: 300px; margin: 0 auto;"></div>
                        </div>
                        <script>
                            window.onload = function() {
                                setTimeout(() => { window.print(); window.close(); }, 500);
                            };
                        <\/script>
                    </body>
                    </html>
                `);
                printWindow.document.close();
            }, 150);
        }
        
        /* ============================================================
           NATIVE SMART SCANNER ENGINE
           ============================================================ */
        let _spStream = null, _spRaf = null, _spTorch = false, _spFacing = 'environment', _spPaused = false, _spBD = null, _spH5 = null;

        function openQRScanner() {
            const panel = document.getElementById('scannerPanel');
            if (!panel) return;
            panel.classList.add('sp-show');
            panel.style.display = 'block';
            document.body.style.overflow = 'hidden';
            document.getElementById('spManualInp').value = '';
            document.getElementById('spNcInp').value = '';

            if ('BarcodeDetector' in window) {
                BarcodeDetector.getSupportedFormats().then(f => { if (f.includes('qr_code')) _spBD = new BarcodeDetector({ formats: ['qr_code'] }); }).catch(() => {});
            }
            _spStartCam();
        }

        function _spStartCam() {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { _spShowNC(); return; }
            document.getElementById('spCamView').style.display = 'block';
            document.getElementById('spNoCam').style.display = 'none';

            navigator.mediaDevices.getUserMedia({ video: { facingMode: _spFacing, width: { ideal: 1280 }, height: { ideal: 720 } } })
                .then(stream => {
                    _spStream = stream;
                    const v = document.getElementById('spVideoEl');
                    v.srcObject = stream;
                    v.onloadedmetadata = () => {
                        v.play();
                        const track = stream.getVideoTracks()[0];
                        const caps = track.getCapabilities ? track.getCapabilities() : {};
                        const btn = document.getElementById('spBtnTorch');
                        if (btn) btn.style.display = caps.torch ? 'flex' : 'none';
                        _spStartLoop(v);
                    };
                })
                .catch(() => _spShowNC());
        }

        function _spStartLoop(v) {
            const canvas = document.getElementById('spCanvas');
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            const CROP = 320;
            _spPaused = false;
            function tick() {
                if (_spPaused || v.readyState < 2) { _spRaf = requestAnimationFrame(tick); return; }
                const vw = v.videoWidth, vh = v.videoHeight;
                if (!vw || !vh) { _spRaf = requestAnimationFrame(tick); return; }
                const cw = Math.min(CROP, vw), ch = Math.min(CROP, vh);
                canvas.width = cw; canvas.height = ch;
                ctx.drawImage(v, Math.max(0,(vw-cw)/2), Math.max(0,(vh-ch)/2), cw, ch, 0, 0, cw, ch);
                (async () => {
                    try {
                        let found = null;
                        if (_spBD) {
                            const r = await _spBD.detect(canvas);
                            if (r.length > 0) found = r[0].rawValue;
                        } else {
                            const id = ctx.getImageData(0, 0, cw, ch);
                            const c = jsQR(id.data, cw, ch, { inversionAttempts: 'dontInvert' });
                            if (c && c.data) found = c.data;
                        }
                        if (found) { _spPaused = true; _spOnFound(found); return; }
                    } catch(e) {}
                    _spRaf = requestAnimationFrame(tick);
                })();
            }
            _spRaf = requestAnimationFrame(tick);
        }

        function _spStopCam() {
            if (_spRaf) { cancelAnimationFrame(_spRaf); _spRaf = null; }
            if (_spStream) { _spStream.getTracks().forEach(t => t.stop()); _spStream = null; }
            _spTorch = false;
            const btn = document.getElementById('spBtnTorch');
            if (btn) btn.classList.remove('sp-lit');
        }

        function spFlipCam() {
            _spFacing = _spFacing === 'environment' ? 'user' : 'environment';
            _spStopCam(); setTimeout(_spStartCam, 200);
        }

        function spToggleTorch() {
            if (!_spStream) return;
            const track = _spStream.getVideoTracks()[0];
            _spTorch = !_spTorch;
            track.applyConstraints({ advanced: [{ torch: _spTorch }] }).catch(() => {});
            document.getElementById('spBtnTorch').classList.toggle('sp-lit', _spTorch);
        }

        function _spShowNC() {
            document.getElementById('spCamView').style.display = 'none';
            document.getElementById('spNoCam').style.display = 'flex';
        }

        function _spOnFound(raw) {
            const code = raw.trim().toUpperCase();
            const f = document.getElementById('spScanFrame');
            if (f) { f.classList.add('sp-pulse'); setTimeout(() => f.classList.remove('sp-pulse'), 350); }
            const item = (allData.items || []).find(i => String(i.code).toUpperCase() === code) || (allData.tools || []).find(i => String(i.code).toUpperCase() === code);
            const pill = document.getElementById('spPill');
            const pillTxt = document.getElementById('spPillTxt');
            if (pill && pillTxt) {
                pillTxt.textContent = item ? item.name : code;
                pill.classList.add('show');
                setTimeout(() => {
                    pill.classList.remove('show');
                    closeScannerPanel();
                    onQRScanSuccess(raw);
                }, 900);
            } else {
                closeScannerPanel();
                onQRScanSuccess(raw);
            }
        }

        function spSubmitManual() {
            const v = document.getElementById('spManualInp').value.trim();
            if (!v) return;
            _spPaused = true;
            _spOnFound(v);
        }

        function spSubmitNC() {
            const v = document.getElementById('spNcInp').value.trim();
            if (!v) return;
            _spOnFound(v);
        }

        function spScanFromFile(event) {
            const file = event.target.files[0]; if (!file) return;
            event.target.value = '';
            const img = new Image(), url = URL.createObjectURL(file);
            img.onload = () => {
                URL.revokeObjectURL(url);
                const result = tryJsQR(img);
                if (result) { _spOnFound(result); return; }
                // fallback html5QrCode
                try {
                    if (!_spH5) _spH5 = new Html5Qrcode('_sp_qr_');
                    _spH5.scanFile(file, true)
                        .then(t => _spOnFound(t))
                        .catch(() => Swal.fire({ icon:'error', title:'อ่าน QR ไม่ได้', html:'<small>QR ต้องชัดเจน ไม่เบลอ แสงสว่างพอ</small>', confirmButtonColor:'#5b6af0' }));
                } catch(e) { Swal.fire({ icon:'error', title:'อ่านไม่ได้', confirmButtonColor:'#5b6af0' }); }
            };
            img.onerror = () => URL.revokeObjectURL(url);
            img.src = url;
        }

        function closeScannerPanel() {
            _spStopCam();
            const panel = document.getElementById('scannerPanel');
            if (panel) panel.style.display = 'none';
            document.body.style.overflow = '';
            _spPaused = false;
        }

        // legacy stubs
        function _openScannerPanel() { openQRScanner(); }
        function stopQRScanner() { closeScannerPanel(); }

        function scanQRFromFile(event) {
            const file = event.target.files[0];
            if (!file) return;
            event.target.value = '';

            document.getElementById('loading').style.display = 'flex';

            const img = new Image();
            const url = URL.createObjectURL(file);

            img.onload = function() {
                URL.revokeObjectURL(url);

                // ลอง jsQR ก่อน (แม่นกว่าสำหรับไฟล์ภาพ)
                const result = tryJsQR(img);
                if (result) {
                    document.getElementById('loading').style.display = 'none';
                    onQRScanSuccess(result);
                    return;
                }

                // fallback: html5QrCode
                tryHtml5QrFallback(file);
            };

            img.onerror = function() {
                URL.revokeObjectURL(url);
                document.getElementById('loading').style.display = 'none';
                Swal.fire({ icon: 'error', title: 'ข้อผิดพลาด', text: 'ไม่สามารถโหลดไฟล์ภาพได้' });
            };

            img.src = url;
        }

        function tryJsQR(img) {
            // ลองหลาย scale และ preprocessing เพื่อเพิ่มโอกาสอ่านสำเร็จ
            const scales = [1.0, 1.5, 2.0, 0.75];

            for (const scale of scales) {
                const w = Math.round(img.naturalWidth * scale);
                const h = Math.round(img.naturalHeight * scale);

                // --- ลอง 1: ภาพปกติ + quiet zone padding ---
                const pad = 40;
                const c1 = document.createElement('canvas');
                c1.width = w + pad * 2;
                c1.height = h + pad * 2;
                const ctx1 = c1.getContext('2d');
                ctx1.fillStyle = '#ffffff';
                ctx1.fillRect(0, 0, c1.width, c1.height);
                ctx1.drawImage(img, pad, pad, w, h);
                let id = ctx1.getImageData(0, 0, c1.width, c1.height);
                let res = jsQR(id.data, c1.width, c1.height, { inversionAttempts: 'attemptBoth' });
                if (res) return res.data;

                // --- ลอง 2: Grayscale + contrast boost ---
                const c2 = document.createElement('canvas');
                c2.width = w + pad * 2;
                c2.height = h + pad * 2;
                const ctx2 = c2.getContext('2d');
                ctx2.fillStyle = '#ffffff';
                ctx2.fillRect(0, 0, c2.width, c2.height);
                ctx2.drawImage(img, pad, pad, w, h);
                id = ctx2.getImageData(0, 0, c2.width, c2.height);
                const d = id.data;
                for (let i = 0; i < d.length; i += 4) {
                    const gray = Math.round(d[i] * 0.299 + d[i+1] * 0.587 + d[i+2] * 0.114);
                    const boosted = gray < 128 ? Math.max(0, gray - 50) : Math.min(255, gray + 50);
                    d[i] = d[i+1] = d[i+2] = boosted;
                }
                ctx2.putImageData(id, 0, 0);
                id = ctx2.getImageData(0, 0, c2.width, c2.height);
                res = jsQR(id.data, c2.width, c2.height, { inversionAttempts: 'attemptBoth' });
                if (res) return res.data;

                // --- ลอง 3: Threshold (binary) ---
                const c3 = document.createElement('canvas');
                c3.width = w + pad * 2;
                c3.height = h + pad * 2;
                const ctx3 = c3.getContext('2d');
                ctx3.fillStyle = '#ffffff';
                ctx3.fillRect(0, 0, c3.width, c3.height);
                ctx3.drawImage(img, pad, pad, w, h);
                id = ctx3.getImageData(0, 0, c3.width, c3.height);
                const d3 = id.data;
                for (let i = 0; i < d3.length; i += 4) {
                    const gray = Math.round(d3[i] * 0.299 + d3[i+1] * 0.587 + d3[i+2] * 0.114);
                    const bin = gray < 140 ? 0 : 255;
                    d3[i] = d3[i+1] = d3[i+2] = bin;
                }
                ctx3.putImageData(id, 0, 0);
                id = ctx3.getImageData(0, 0, c3.width, c3.height);
                res = jsQR(id.data, c3.width, c3.height, { inversionAttempts: 'attemptBoth' });
                if (res) return res.data;
            }

            return null;
        }

        function tryHtml5QrFallback(file) {
            if (!html5QrCode) {
                html5QrCode = new Html5Qrcode("loading");
            }
            html5QrCode.scanFile(file, true)
                .then(decodedText => {
                    document.getElementById('loading').style.display = 'none';
                    onQRScanSuccess(decodedText);
                })
                .catch(() => {
                    document.getElementById('loading').style.display = 'none';
                    Swal.fire({
                        icon: 'error',
                        title: 'อ่าน QR ไม่ได้',
                        html: `<div class="text-start small">
                            <b>เพื่อผลลัพธ์ที่ดีขึ้น:</b>
                            <ul class="mt-2 text-muted" style="padding-left:1.2rem;">
                                <li>ถ่ายให้ QR อยู่ตรงกลางภาพ</li>
                                <li>แสงสว่างเพียงพอ ไม่มีเงา</li>
                                <li>Crop เฉพาะส่วน QR ก่อนส่ง</li>
                                <li>ระยะห่างพอเหมาะ ไม่ใกล้เกินไป</li>
                            </ul>
                        </div>`,
                        confirmButtonColor: '#4f46e5'
                    });
                });
        }

        function onQRScanSuccess(decodedText) {
            try {
                if (html5QrCode && html5QrCode.isScanning) {
                    html5QrCode.pause();
                }
            } catch(e) {}
            
            const code = String(decodedText).trim();
            const item = allData.items.find(i => i.code === code) || allData.tools.find(t => t.code === code);
            
            if (!item) {
                Swal.fire({
                    icon: 'error',
                    title: 'ไม่พบรายการ',
                    text: `ไม่พบรหัส ${code} ในระบบ`,
                    confirmButtonText: 'สแกนใหม่',
                    confirmButtonColor: '#4f46e5'
                }).then(() => {
                    try { if (html5QrCode && html5QrCode.isScanning) html5QrCode.resume(); } catch(e) {}
                });
                return;
            }

            scannedItemContext = item;
            
            stopQRScanner();
            
            document.getElementById('scanActionName').innerText = item.name;
            document.getElementById('scanActionCode').innerText = item.code;
            
            const locText = item.location ? `<i class="fas fa-map-marker-alt text-danger me-1"></i> ${item.location}` : `<i class="fas fa-map-marker-alt text-muted me-1"></i> -`;
            document.getElementById('scanActionLoc').innerHTML = locText;
            
            const isTool = allData.tools.some(t => t.code === item.code);
            const stockClass = item.stock <= item.min ? 'text-danger' : 'text-primary';
            document.getElementById('scanActionStock').innerHTML = `คงเหลือ: <span class="fw-bold ${stockClass}">${formatNumber(item.stock)}</span> <small class="text-muted">${item.unit}</small>`;
            
            document.getElementById('scanQtyInput').value = 1;
            
            const borrowBtn = document.querySelector('#qrActionModal .btn-warning');
            if (borrowBtn) {
                borrowBtn.innerHTML = isTool ? '<i class="fas fa-tools me-1"></i> ยืม (Borrow Tool)' : '<i class="fas fa-hand-holding me-1"></i> ยืม (Borrow Item)';
            }
            
            qrActionModal.show();
        }

        function stopQRScanner() {
            // legacy alias — delegate to new panel close
            closeScannerPanel();
        }

        function adjustScanQty(change) {
            const input = document.getElementById('scanQtyInput');
            let current = parseFloat(input.value) || 0;
            let step = 1;
            let decimals = parseInt(allData.settings?.decimalPlaces) || 0;
            if (decimals === 1) step = 0.1;
            else if (decimals === 2) step = 0.01;
            
            let nextVal = current + (change * step);
            if (nextVal < step) nextVal = step;
            input.value = nextVal.toFixed(decimals);
        }

        function handleScanAction(actionType) {
            if (!scannedItemContext) return;
            const inputQty = parseFloat(document.getElementById('scanQtyInput').value) || 0;
            if (inputQty <= 0 || !Number.isInteger(inputQty)) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: 'ระบุจำนวนเป็นจำนวนเต็มอย่างน้อย 1'});
            
            const code = scannedItemContext.code;
            const isTool = allData.tools.some(t => t.code === code);
            
            qrActionModal.hide();
            
            setTimeout(() => {
                if (actionType === 'in') {
                    goTo('transactionsInOut'); openTxModal('รับเข้า');
                    setTimeout(() => { 
                        if(window.txSelectInstance) window.txSelectInstance.setValue(code); 
                        document.getElementById('txQty').value = inputQty;
                    }, 300);
                } 
                else if (actionType === 'out') {
                    if(scannedItemContext.stock < inputQty) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: `ไม่สามารถเบิกออกได้ (มีสต็อกเหลือแค่ ${scannedItemContext.stock})`});
                    goTo('transactionsInOut'); openTxModal('เบิก');
                    setTimeout(() => { 
                        if(window.txSelectInstance) window.txSelectInstance.setValue(code); 
                        document.getElementById('txQty').value = inputQty;
                    }, 300);
                }
                else if (actionType === 'borrow') {
                    if(scannedItemContext.stock < inputQty) return Swal.fire({icon: 'warning', title: 'แจ้งเตือน', text: `ไม่สามารถยืมได้ (มีของให้ยืมแค่ ${scannedItemContext.stock})`});
                    goTo('borrowedItems'); openAddBorrowModal(isTool ? 'Tools' : 'Items');
                    setTimeout(() => { 
                        if(window.borrowSelectInstance) window.borrowSelectInstance.setValue(code); 
                        document.getElementById('borrowQty').value = inputQty;
                    }, 300);
                }
            }, 400);
        }

        function exportExcel(tableId, filename) {
            const table = document.getElementById(tableId);
            if(!table) return;
            const wb = XLSX.utils.table_to_book(table, {sheet: "Sheet1"});
            XLSX.writeFile(wb, `${filename}_${new Date().toISOString().split('T')[0]}.xlsx`);
        }


        function printSingleQRCode() {
            const code = document.getElementById('qrItemCode').innerText;
            const name = document.getElementById('qrItemName').innerText;
            if (!code || code === 'CODE-123') return;
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Print QR Code - ${code}</title>
                    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@400;600;700&display=swap" rel="stylesheet">
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"><\/script>
                    <style>
                        body { font-family: 'Prompt', sans-serif; margin: 0; padding: 20px; display: flex; justify-content: center; align-items: center; min-height: 100vh; background: #fff; }
                        .label-card { border: 2px dashed #94a3b8; border-radius: 12px; padding: 20px; text-align: center; width: 250px; }
                        .qr-placeholder { display: flex; justify-content: center; margin-bottom: 15px; }
                        .item-name { font-size: 16px; font-weight: 700; color: #1e293b; margin: 0 0 8px 0; line-height: 1.3; }
                        .item-code { font-size: 14px; font-family: monospace; background: #f1f5f9; padding: 4px 10px; border-radius: 6px; border: 1px solid #cbd5e1; margin: 0; font-weight: bold; }
                        @media print { body { padding: 0; align-items: flex-start; } .label-card { border: 1px solid #000; margin: 0; width: 100%; height: 100vh; box-sizing: border-box; border-radius: 0; display: flex; flex-direction: column; justify-content: center; } }
                    </style>
                </head>
                <body>
                    <div class="label-card">
                        <div id="qr-single" class="qr-placeholder"></div>
                        <h3 class="item-name">${name}</h3>
                        <p class="item-code">${code}</p>
                    </div>
                    <script>
                        window.onload = function() {
                            setTimeout(() => {
                                new QRCode(document.getElementById('qr-single'), { text: "${code}", width: 180, height: 180, colorDark: "#000000", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.M });
                                setTimeout(() => { window.print(); window.close(); }, 800);
                            }, 300);
                        };
                    <\/script>
                </body>
                </html>
            `);
            printWindow.document.close();
            
            // บันทึกประวัติการพิมพ์
            const printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
            const historyRecord = {
                id: Date.now(),
                itemName: name,
                itemCode: code,
                printedAt: new Date().toLocaleString('th-TH'),
                timestamp: Date.now(),
                type: 'QR Code'
            };
            printHistory.unshift(historyRecord);
            localStorage.setItem('qrBarcodeHistory', JSON.stringify(printHistory));
            
            // อัปเดตตารางประวัติ
            updateHistoryTable();
            updateHistoryStats();
        }
        
        // ฟังก์ชันโหลดและแสดงตารางประวัติ
        function updateHistoryTable() {
            const printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
            const tbody = document.querySelector('#historyTableBody');
            
            if (!tbody) return;
            
            tbody.innerHTML = '';
            
            if (printHistory.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">ยังไม่มีประวัติการพิมพ์</td></tr>';
                return;
            }
            
            printHistory.forEach((record, index) => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td><strong>${index + 1}</strong></td>
                    <td><span class="badge ${record.type === 'QR Code' ? 'bg-primary' : 'bg-success'}">${record.type}</span></td>
                    <td><strong>${record.itemName}</strong></td>
                    <td><code style="background:#f1f5f9;padding:4px 8px;border-radius:4px;font-size:0.85rem;">${record.itemCode}</code></td>
                    <td>${record.printedAt}</td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteHistoryRecord(${record.id})" title="ลบบันทึก">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
        
        // สถิติประวัติ
        function updateHistoryStats() {
            const printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
            
            if (document.getElementById('totalPrints')) {
                document.getElementById('totalPrints').innerText = printHistory.length;
            }
            
            if (document.getElementById('uniqueItems')) {
                const uniqueItems = new Set(printHistory.map(r => r.itemCode)).size;
                document.getElementById('uniqueItems').innerText = uniqueItems;
            }
            
            if (document.getElementById('todayPrints')) {
                const today = new Date().toDateString();
                const todayPrints = printHistory.filter(r => new Date(r.timestamp).toDateString() === today).length;
                document.getElementById('todayPrints').innerText = todayPrints;
            }
            
            // อัปเดตตารางสินค้าที่พิมพ์มากที่สุด
            updateTopPrintedItems();
        }
        
        // ตารางสินค้าที่พิมพ์มากที่สุด
        function updateTopPrintedItems() {
            const printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
            const itemCount = {};
            
            printHistory.forEach(record => {
                const key = record.itemCode;
                itemCount[key] = (itemCount[key] || 0) + 1;
            });
            
            const sorted = Object.entries(itemCount)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);
            
            const tbody = document.querySelector('#topItemsBody');
            if (!tbody) return;
            
            tbody.innerHTML = '';
            
            if (sorted.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">ยังไม่มีข้อมูล</td></tr>';
                return;
            }
            
            sorted.forEach((item, index) => {
                const record = printHistory.find(r => r.itemCode === item[0]);
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="text-center"><strong>${index + 1}</strong></td>
                    <td>
                        <div><strong>${record.itemName}</strong></div>
                        <small style="color:#64748b;"><code>${item[0]}</code></small>
                    </td>
                    <td class="text-center"><span class="badge bg-primary" style="font-size:0.9rem;padding:8px 12px;">${item[1]} ครั้ง</span></td>
                `;
                tbody.appendChild(row);
            });
        }
        
        // ลบบันทึกประวัติ
        function deleteHistoryRecord(id) {
            Swal.fire({
                title: 'ยืนยันการลบ',
                text: 'ต้องการลบบันทึกการพิมพ์นี้หรือไม่?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'ลบ',
                cancelButtonText: 'ยกเลิก'
            }).then(result => {
                if (result.isConfirmed) {
                    let printHistory = JSON.parse(localStorage.getItem('qrBarcodeHistory') || '[]');
                    printHistory = printHistory.filter(r => r.id !== id);
                    localStorage.setItem('qrBarcodeHistory', JSON.stringify(printHistory));
                    updateHistoryTable();
                    updateHistoryStats();
                    Swal.fire('ลบแล้ว', 'ลบบันทึกการพิมพ์สำเร็จ', 'success');
                }
            });
        }
        
        // ลบประวัติทั้งหมด
        function clearAllHistory() {
            Swal.fire({
                title: 'ล้างประวัติทั้งหมด',
                text: 'ต้องการลบประวัติการพิมพ์ทั้งหมดหรือไม่? การกระทำนี้ไม่สามารถเลิกทำได้',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'ลบทั้งหมด',
                cancelButtonText: 'ยกเลิก',
                confirmButtonColor: '#ef4444'
            }).then(result => {
                if (result.isConfirmed) {
                    localStorage.setItem('qrBarcodeHistory', JSON.stringify([]));
                    updateHistoryTable();
                    updateHistoryStats();
                    Swal.fire('ล้างแล้ว', 'ลบประวัติการพิมพ์ทั้งหมดสำเร็จ', 'success');
                }
            });
        }
        
        // โหลดประวัติเมื่อเปิดหน้า
        // updateHistoryTable จะถูกเรียกเมื่อ goTo('history') แทน

        /* ============================================================
           CHANGE PIN MODAL — ทุก role เข้าถึงได้
        ============================================================ */
        function openChangePinModal() {
            const nameEl = document.getElementById('changePinUserName');
            const roleEl = document.getElementById('changePinUserRole');
            if (nameEl) nameEl.innerText = currentUserProfile.name || '-';
            if (roleEl) roleEl.innerText = currentUserProfile.role === 'admin' ? '👑 Admin' : '👤 User';
            document.getElementById('changePinNew').value = '';
            document.getElementById('changePinConfirm').value = '';
            changePinModal.show();
            setTimeout(() => document.getElementById('changePinNew').focus(), 400);
        }

        function submitChangePin() {
            const pin1 = document.getElementById('changePinNew').value.trim();
            const pin2 = document.getElementById('changePinConfirm').value.trim();
            if (!pin1 || !pin2) return Swal.fire({icon:'warning', title:'แจ้งเตือน', text:'กรุณากรอก PIN ให้ครบทั้งสองช่อง'});
            if (!/^\d{4,6}$/.test(pin1)) return Swal.fire({icon:'warning', title:'แจ้งเตือน', text:'PIN ต้องเป็นตัวเลข 4-6 หลักเท่านั้น'});
            if (pin1 !== pin2) return Swal.fire({icon:'warning', title:'แจ้งเตือน', text:'PIN ไม่ตรงกัน กรุณาตรวจสอบอีกครั้ง'});
            if (!currentUserProfile.uid) return Swal.fire({icon:'error', title:'ข้อผิดพลาด', text:'ไม่พบรหัสประจำตัว กรุณาออกจากระบบแล้วเข้าใหม่'});

            document.getElementById('loading').style.display = 'flex';
            changePinModal.hide();

            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run
                    .withSuccessHandler(function(res) {
                        document.getElementById('loading').style.display = 'none';
                        if (res && res.success) {
                            writeAudit('SETTINGS', `เปลี่ยน PIN ส่วนตัวสำเร็จ — ${currentUserProfile.name}`);
                            Swal.fire({icon:'success', title:'สำเร็จ!', text:'เปลี่ยน PIN เรียบร้อยแล้ว ใช้ PIN ใหม่ในการเข้าสู่ระบบครั้งหน้า', timer:2500, showConfirmButton:false});
                        } else {
                            Swal.fire({icon:'error', title:'ข้อผิดพลาด', text: res ? res.error : 'ไม่สามารถเปลี่ยน PIN ได้'});
                        }
                    })
                    .withFailureHandler(function(err) {
                        document.getElementById('loading').style.display = 'none';
                        Swal.fire({icon:'error', title:'ข้อผิดพลาด', text: String(err)});
                    })
                    .webUpdateUserPin(currentUserProfile.uid, pin1);
            } else {
                setTimeout(() => {
                    document.getElementById('loading').style.display = 'none';
                    Swal.fire({icon:'success', title:'สำเร็จ! (Demo)', text:'เปลี่ยน PIN เรียบร้อยแล้ว', timer:2000, showConfirmButton:false});
                }, 500);
            }
        }

        /* ============================================================
           SYSTEM AUDIT LOG ENGINE (Centralized — Google Sheet)
        ============================================================ */

        // cache ใน memory สำหรับ render เร็ว
        let _auditCache = [];

        const AUDIT_TYPE_META = {
            'LOGIN':       { label: 'เข้าสู่ระบบ',       badge: 'bg-success bg-opacity-10 text-success',    icon: 'fa-sign-in-alt' },
            'LOGOUT':      { label: 'ออกจากระบบ',         badge: 'bg-secondary bg-opacity-10 text-secondary', icon: 'fa-sign-out-alt' },
            'TRANSACTION': { label: 'ทำรายการสินค้า',     badge: 'bg-primary bg-opacity-10 text-primary',    icon: 'fa-exchange-alt' },
            'NEW_ITEM':    { label: 'เพิ่มรายการใหม่',    badge: 'bg-info bg-opacity-10 text-info',          icon: 'fa-plus-circle' },
            'EDIT_ITEM':   { label: 'แก้ไขข้อมูล',        badge: 'bg-warning bg-opacity-10 text-warning',    icon: 'fa-edit' },
            'ADJUST':      { label: 'ปรับยอด Manual',     badge: 'bg-warning bg-opacity-10 text-warning',    icon: 'fa-sliders-h' },
            'BORROW':      { label: 'ยืม/คืน',            badge: 'bg-primary bg-opacity-10 text-primary',    icon: 'fa-hand-holding' },
            'DAMAGE':      { label: 'แจ้งชำรุด/ซ่อม',    badge: 'bg-danger bg-opacity-10 text-danger',      icon: 'fa-heart-broken' },
            'PO':          { label: 'จัดการ PO',           badge: 'bg-warning bg-opacity-10 text-warning',    icon: 'fa-file-invoice' },
            'SETTINGS':    { label: 'ตั้งค่าระบบ',         badge: 'bg-dark bg-opacity-10 text-dark',          icon: 'fa-cog' },
            'USER_MGMT':   { label: 'จัดการผู้ใช้',       badge: 'bg-danger bg-opacity-10 text-danger',      icon: 'fa-users-cog' },
        };

        // ส่ง audit ไป Google Sheet (fire-and-forget ไม่บล็อก UI)
        function writeAudit(type, detail, status = 'SUCCESS') {
            try {
                const payload = {
                    type:   type,
                    user:   currentUserProfile.name  || 'ไม่ระบุ',
                    userId: currentUserProfile.uid   || '-',
                    role:   currentUserProfile.role  || '-',
                    detail: detail,
                    device: /Mobi|Android/i.test(navigator.userAgent) ? 'Mobile' : 'Desktop',
                    status: status
                };

                // เพิ่มใน cache ทันที (optimistic UI)
                const now = new Date();
                const pad = n => String(n).padStart(2,'0');
                const isEn = allData.settings?.dateFormat === 'EN';
                const yr = isEn ? now.getFullYear() : now.getFullYear() + 543;
                payload.time = `${pad(now.getDate())}/${pad(now.getMonth()+1)}/${String(yr).slice(-2)} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
                payload.timestamp = now.getTime();
                _auditCache.unshift(payload);
                if (_auditCache.length > 500) _auditCache.pop();

                // ส่งไป server แบบ async (ไม่รอ)
                if (typeof google !== 'undefined' && google.script && google.script.run) {
                    google.script.run.webWriteAudit(payload);
                }
            } catch(e) { console.warn('Audit write error:', e); }
        }

        // โหลด log จาก server มาใส่ cache แล้ว render
        function loadAuditFromServer(forceRefresh) {
            // ถ้ามี cache อยู่แล้ว และไม่ได้ force → append เฉพาะรายการใหม่
            const hasCached = _auditCache.length > 0;

            if (!forceRefresh && hasCached) {
                // render จาก cache ที่มีอยู่ก่อนเลย (ไม่กระพริบ)
                filterAuditLog();
            } else {
                // ครั้งแรกหรือ force → แสดง spinner เฉพาะ tbody ไม่กระทบส่วนอื่น
                const tbody = document.getElementById('auditLogTableBody');
                if (tbody && !hasCached) {
                    tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-muted"><div class="spinner-border spinner-border-sm text-primary me-2"></div>กำลังโหลด Audit Log...</td></tr>`;
                }
            }

            if (typeof google !== 'undefined' && google.script && google.script.run) {
                google.script.run
                    .withSuccessHandler(function(res) {
                        if (res && res.success && res.logs) {
                            if (!forceRefresh && hasCached && res.logs.length > 0) {
                                // merge เฉพาะรายการที่ใหม่กว่า cache รายการแรก
                                const latestCached = _auditCache[0]?.time || '';
                                const newItems = res.logs.filter(l => l.time > latestCached);
                                if (newItems.length > 0) {
                                    _auditCache = [...newItems, ..._auditCache].slice(0, 500);
                                }
                            } else {
                                _auditCache = res.logs;
                            }
                        }
                        filterAuditLog();
                    })
                    .withFailureHandler(function(err) {
                        console.warn('Audit load error:', err);
                        filterAuditLog();
                    })
                    .webGetAuditLogs(500);
            } else {
                filterAuditLog();
            }
        }

        function renderAuditLog(logs) {
            const tbody = document.getElementById('auditLogTableBody');
            if (!tbody) return;
            tbody.innerHTML = '';
            if (!logs || logs.length === 0) {
                tbody.innerHTML = `<tr><td colspan="6" class="text-center py-5 text-muted">
                    <i class="fas fa-shield-alt fs-3 d-block mb-2 opacity-25"></i>
                    ยังไม่มีข้อมูล Audit Log<br>
                    <small>Log จะเริ่มบันทึกเมื่อมีการทำรายการครั้งแรก</small>
                </td></tr>`;
                return;
            }
            logs.forEach(log => {
                const meta = AUDIT_TYPE_META[log.type] || { label: log.type, badge: 'bg-secondary bg-opacity-10 text-secondary', icon: 'fa-circle' };
                const statusBadge = log.status === 'SUCCESS'
                    ? '<span class="badge bg-success bg-opacity-10 text-success px-2 py-1"><i class="fas fa-check me-1"></i>สำเร็จ</span>'
                    : '<span class="badge bg-danger bg-opacity-10 text-danger px-2 py-1"><i class="fas fa-times me-1"></i>ล้มเหลว</span>';
                const roleBadge = log.role === 'admin'
                    ? '<span class="badge ms-1" style="font-size:0.68em;">Admin</span>'
                    : '<span class="badge bg-light text-muted border ms-1" style="font-size:0.68em;">User</span>';
                const deviceIcon = (log.device || log.ua || '') === 'Mobile' ? 'fa-mobile-alt' : 'fa-desktop';
                const deviceText = log.device || log.ua || 'Web';
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><small class="font-monospace text-muted bg-light px-2 py-1 rounded d-inline-block">${log.time}</small></td>
                    <td class="text-center"><span class="badge ${meta.badge} px-2 py-2 w-100"><i class="fas ${meta.icon} me-1"></i>${meta.label}</span></td>
                    <td>
                        <div class="fw-bold text-dark small">${log.user}${roleBadge}</div>
                        <div class="text-muted" style="font-size:0.7em;font-family:monospace;">${String(log.userId||'').substring(0,14)}…</div>
                    </td>
                    <td class="small text-dark">${log.detail}</td>
                    <td class="text-center"><i class="fas ${deviceIcon} text-muted"></i><br><small class="text-muted" style="font-size:0.7em;">${deviceText}</small></td>
                    <td class="text-center">${statusBadge}</td>
                `;
                tbody.appendChild(tr);
            });
        }

        function updateAuditStats(logs) {
            const now = new Date();
            const pad = n => String(n).padStart(2,'0');
            // สร้าง todayStr ให้ตรงกับ format ที่ backend บันทึก: DD/MM/YY
            const isEn = allData.settings?.dateFormat === 'EN';
            const yr = isEn ? now.getFullYear() : now.getFullYear() + 543;
            const todayPrefix = `${pad(now.getDate())}/${pad(now.getMonth()+1)}/${String(yr).slice(-2)}`;

            const safeSet = (id, val) => { const el = document.getElementById(id); if(el) el.innerText = val; };
            safeSet('auditTotalCount', logs.length);
            safeSet('auditLoginToday', logs.filter(l => l.type === 'LOGIN' && String(l.time || '').startsWith(todayPrefix)).length);
            safeSet('auditDataChange', logs.filter(l => ['TRANSACTION','NEW_ITEM','EDIT_ITEM','ADJUST','BORROW','DAMAGE','PO'].includes(l.type)).length);
            safeSet('auditTodayCount', logs.filter(l => String(l.time || '').startsWith(todayPrefix)).length);
        }

        function filterAuditLog() {
            const typeFilter  = (document.getElementById('auditTypeFilter')?.value || '').trim();
            const searchText  = (document.getElementById('auditSearch')?.value || '').toLowerCase().trim();
            const dateFrom    = document.getElementById('auditDateFrom')?.value;
            const dateTo      = document.getElementById('auditDateTo')?.value;

            const all = _auditCache;
            const filtered = all.filter(log => {
                if (typeFilter && log.type !== typeFilter) return false;
                if (searchText) {
                    const hay = `${log.user} ${log.detail} ${log.type} ${log.role}`.toLowerCase();
                    if (!hay.includes(searchText)) return false;
                }
                // กรองวันที่จาก string "DD/MM/YY HH:MM:SS"
                if (dateFrom || dateTo) {
                    const parts = String(log.time || '').split(' ')[0].split('/');
                    if (parts.length === 3) {
                        const isEn = allData.settings?.dateFormat === 'EN';
                        const yr = isEn ? parseInt(parts[2]) + 2000 : parseInt(parts[2]) + 2500 - 543;
                        const logDate = new Date(yr, parseInt(parts[1])-1, parseInt(parts[0]));
                        if (dateFrom) { const f = new Date(dateFrom); f.setHours(0,0,0,0); if (logDate < f) return false; }
                        if (dateTo)   { const t = new Date(dateTo);   t.setHours(23,59,59,999); if (logDate > t) return false; }
                    }
                }
                return true;
            });

            renderAuditLog(filtered);
            updateAuditStats(all);
            const shown = document.getElementById('auditShownCount'); if(shown) shown.innerText = filtered.length;
            const tot   = document.getElementById('auditTotalShown'); if(tot)   tot.innerText   = all.length;
        }

        function resetAuditFilter() {
            ['auditTypeFilter','auditSearch','auditDateFrom','auditDateTo'].forEach(id => {
                const el = document.getElementById(id); if(el) el.value = '';
            });
            filterAuditLog();
        }

        function clearAuditLog() {
            if (currentUserProfile.role !== 'admin') return Swal.fire({icon:'error', title:'ปฏิเสธ', text:'เฉพาะ Admin เท่านั้น'});
            Swal.fire({
                title: 'ล้าง Audit Log?',
                text: 'บันทึกกิจกรรมทั้งหมดจะถูกลบออกจาก Google Sheet ไม่สามารถย้อนกลับได้',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'ล้างทิ้ง',
                cancelButtonText: 'ยกเลิก'
            }).then(r => {
                if (r.isConfirmed) {
                    document.getElementById('loading').style.display = 'flex';
                    if (typeof google !== 'undefined' && google.script && google.script.run) {
                        google.script.run
                            .withSuccessHandler(function(res) {
                                document.getElementById('loading').style.display = 'none';
                                if (!res.success) return Swal.fire({icon:'error', title:'ข้อผิดพลาด', text: res.error});
                                _auditCache = [];
                                loadAuditFromServer(true);
                                Swal.fire({ icon:'success', title:'ล้างแล้ว', timer:1500, showConfirmButton:false });
                            })
                            .withFailureHandler(function(err) {
                                document.getElementById('loading').style.display = 'none';
                                Swal.fire({icon:'error', title:'ข้อผิดพลาด', text: String(err)});
                            })
                            .webClearAuditLog(currentUserProfile.name);
                    } else {
                        document.getElementById('loading').style.display = 'none';
                        _auditCache = [];
                        filterAuditLog();
                        Swal.fire({ icon:'success', title:'ล้างแล้ว (Demo)', timer:1500, showConfirmButton:false });
                    }
                }
            });
        }

        function exportAuditLog() {
            const all = _auditCache;
            if (!all.length) return Swal.fire({ icon:'warning', title:'ไม่มีข้อมูล', text:'ยังไม่มี Audit Log ให้ Export' });
            const rows = all.map(l => ({
                'วันเวลา':         l.time,
                'ประเภท':          (AUDIT_TYPE_META[l.type]||{label:l.type}).label,
                'ผู้ดำเนินการ':    l.user,
                'UID':             l.userId,
                'สิทธิ์':          l.role,
                'รายละเอียด':      l.detail,
                'Device':          l.device || l.ua || 'Web',
                'สถานะ':           l.status
            }));
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'AuditLog');
            XLSX.writeFile(wb, `System_AuditLog_${new Date().toISOString().split('T')[0]}.xlsx`);
        }